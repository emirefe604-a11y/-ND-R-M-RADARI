import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'notify.dart';
import 'scraper.dart';
import 'search_page.dart';
import 'store.dart';
import 'theme.dart';
import 'track_page.dart';
import 'tracker.dart';
import 'webfetch.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Notify.init();
    await schedulePriceChecks();
  } catch (_) {}
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'İndirim Radarı',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: orange, primary: orange),
          scaffoldBackgroundColor: bgColor,
          navigationBarTheme: NavigationBarThemeData(
            backgroundColor: Colors.white,
            indicatorColor: const Color(0xFFFFE3CF),
          ),
        ),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> with WidgetsBindingObserver {
  final _web = WebFetcher();
  final _tracked = ValueNotifier<List<Tracked>>([]);
  bool _refreshing = false;
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    Notify.requestPermission();
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _load() async => _tracked.value = await Store.load();

  Future<void> _refresh() async {
    if (_refreshing) return;
    _refreshing = true;
    try {
      await checkAll(web: _web);
      await _load();
    } catch (_) {
    } finally {
      _refreshing = false;
    }
  }

  void _say(String m) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));

  Future<void> _toggle(Offer o) async {
    final l = List<Tracked>.of(_tracked.value);
    final i = l.indexWhere((t) => t.url == o.url);
    if (i >= 0) {
      l.removeAt(i);
      _say('Takip bırakıldı');
    } else {
      l.add(Tracked(
          url: o.url, title: o.title, store: o.store, price: o.price, checked: DateTime.now()));
      _say('Takibe alındı, fiyat düşünce bildirim gelecek 🔔');
    }
    await Store.save(l);
    _tracked.value = l;
  }

  Future<void> _remove(Tracked t) async {
    final l = _tracked.value.where((e) => e.url != t.url).toList();
    await Store.save(l);
    _tracked.value = l;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        IndexedStack(index: _tab, children: [
          SearchPage(web: _web, tracked: _tracked, onToggle: _toggle),
          TrackPage(tracked: _tracked, onRefresh: _refresh, onRemove: _remove),
        ]),
        // Gizli WebView: JS ile çizilen siteler için
        Positioned(left: 0, top: 0, width: 1, height: 1, child: WebViewWidget(controller: _web.controller)),
      ]),
      bottomNavigationBar: ValueListenableBuilder<List<Tracked>>(
        valueListenable: _tracked,
        builder: (_, list, __) => NavigationBar(
          selectedIndex: _tab,
          onDestinationSelected: (i) => setState(() => _tab = i),
          destinations: [
            const NavigationDestination(icon: Icon(Icons.search_rounded), label: 'Ara'),
            NavigationDestination(
              icon: Badge(
                  isLabelVisible: list.isNotEmpty,
                  label: Text('${list.length}'),
                  child: const Icon(Icons.notifications_active_outlined)),
              label: 'Takip',
            ),
          ],
        ),
      ),
    );
  }
}
