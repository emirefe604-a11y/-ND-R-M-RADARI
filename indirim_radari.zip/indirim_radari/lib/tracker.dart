import 'package:android_intent_plus/android_intent.dart';
import 'package:workmanager/workmanager.dart';
import 'notify.dart';
import 'scraper.dart';
import 'store.dart';
import 'webfetch.dart';

/// Takipteki tüm ürünlerin fiyatını kontrol eder, düşenler için bildirim gönderir.
/// [web] verilirse (uygulama açıkken) JS ile çizilen sayfalar için WebView yedeği kullanılır.
Future<int> checkAll({WebFetcher? web}) async {
  final list = await Store.load();
  var drops = 0;
  for (final t in list) {
    double? np;
    try {
      np = await fetchPrice(t.url, web: web);
    } catch (_) {}
    t.checked = DateTime.now();
    if (np == null) continue;
    final drop = np < t.price - 0.01;
    // Hedef fiyat varsa: hedefe/altına inince bildir. Yoksa: her düşüşte bildir.
    final notifyNow = t.target != null ? (drop && np <= t.target!) : drop;
    if (notifyNow) {
      drops++;
      final pct = ((t.price - np) / t.price * 100).round();
      final record = np < t.lowest - 0.01;
      final head = record
          ? '🔥 Rekor düşük fiyat! ${t.store}'
          : t.target != null
              ? '🎯 Hedef fiyata ulaştı! ${t.store}'
              : 'İndirim! ${t.store}';
      await Notify.show(t.url.hashCode & 0x7fffffff, head,
          '${t.title}\n${fmt(t.price)} → ${fmt(np)}  (%$pct)',
          payload: t.url);
    }
    t.record(np);
    t.price = np;
    if (np < t.lowest) t.lowest = np;
  }
  await Store.save(list);
  return drops;
}

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, input) async {
    try {
      await checkAll();
    } catch (_) {}
    return true;
  });
}

const _uid = 'indirim-radari-kontrol';

Future<void> _register(int minutes) => Workmanager().registerPeriodicTask(
      _uid,
      'fiyatKontrol',
      frequency: Duration(minutes: minutes), // Android alt sınırı 15 dk
      constraints: Constraints(networkType: NetworkType.connected),
    );

Future<void> schedulePriceChecks() async {
  await Workmanager().initialize(callbackDispatcher);
  await _register(await Settings.intervalMin());
}

/// Ayarlardan aralık değişince eski işi iptal edip yenisini kurar.
Future<void> rescheduleChecks() async {
  await Workmanager().cancelByUniqueName(_uid);
  await _register(await Settings.intervalMin());
}

/// Android pil kısıtlamasından muaf tutma isteği (bildirimlerin gecikmemesi için).
Future<void> requestBatteryExemption() async {
  try {
    await const AndroidIntent(
      action: 'android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS',
      data: 'package:com.indirimradari.indirim_radari',
    ).launch();
  } catch (_) {}
}
