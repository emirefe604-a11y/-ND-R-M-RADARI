import 'package:html/dom.dart';
import 'package:html/parser.dart' as parser;
import 'package:http/http.dart' as http;
import 'webfetch.dart';

class Offer {
  final String store, title, priceText, url;
  final double price;
  Offer(this.store, this.title, this.priceText, this.price, this.url);
}

class Site {
  final String name, base;
  final String Function(String q) searchUrl;
  final Set<String>? cats; // null = tüm kategoriler
  final bool searchable; // false = sadece sayfa açılır (ör. BİM)
  final bool core; // "Tümü" aramasına dahil mi?
  const Site(this.name, this.base, this.searchUrl,
      {this.cats, this.searchable = true, this.core = false});
}

String _q(String q) => Uri.encodeQueryComponent(q);

/// Arama adresi şablonu: {q} yerine aranan metin gelir.
Site _s(String name, String base, String tmpl,
        {Set<String>? cats, bool core = false, bool searchable = true}) =>
    Site(name, base, (q) => tmpl.replaceFirst('{q}', _q(q)),
        cats: cats, core: core, searchable: searchable);

const categories = [
  'Tümü', 'Market', 'Elektronik', 'Giyim', 'Ev & Yaşam', 'Yapı & Bahçe',
  'Kozmetik', 'Anne & Bebek', 'Spor', 'Oyuncak', 'Kitap', 'Evcil Hayvan',
];

// Yeni site eklemek için tek satır yeterli.
final sites = <Site>[
  // ── Genel (her kategoride aranır; core = "Tümü"de de aranır)
  _s('Cimri', 'https://www.cimri.com', 'https://www.cimri.com/arama?q={q}', core: true),
  _s('Akakçe', 'https://www.akakce.com', 'https://www.akakce.com/arama/?q={q}', core: true),
  _s('Trendyol', 'https://www.trendyol.com', 'https://www.trendyol.com/sr?q={q}', core: true),
  _s('Hepsiburada', 'https://www.hepsiburada.com', 'https://www.hepsiburada.com/ara?q={q}', core: true),
  _s('n11', 'https://www.n11.com', 'https://www.n11.com/arama?q={q}', core: true),
  _s('Amazon TR', 'https://www.amazon.com.tr', 'https://www.amazon.com.tr/s?k={q}', core: true),
  _s('PTT AVM', 'https://www.pttavm.com', 'https://www.pttavm.com/arama?q={q}'),
  _s('Pazarama', 'https://www.pazarama.com', 'https://www.pazarama.com/arama?q={q}'),

  // ── Elektronik
  _s('Epey', 'https://www.epey.com', 'https://www.epey.com/ara/?q={q}', cats: {'Elektronik'}),
  _s('Teknosa', 'https://www.teknosa.com', 'https://www.teknosa.com/arama?s={q}', cats: {'Elektronik'}),
  _s('MediaMarkt', 'https://www.mediamarkt.com.tr',
      'https://www.mediamarkt.com.tr/tr/search.html?query={q}', cats: {'Elektronik'}),
  _s('Vatan Bilgisayar', 'https://www.vatanbilgisayar.com',
      'https://www.vatanbilgisayar.com/arama/{q}/', cats: {'Elektronik'}),
  _s('İnceHesap', 'https://www.incehesap.com', 'https://www.incehesap.com/arama/?q={q}',
      cats: {'Elektronik'}),

  // ── Market
  _s('A101', 'https://www.a101.com.tr', 'https://www.a101.com.tr/arama?k={q}', cats: {'Market'}),
  _s('ŞOK', 'https://www.sokmarket.com.tr', 'https://www.sokmarket.com.tr/arama?q={q}',
      cats: {'Market'}),
  _s('Migros', 'https://www.migros.com.tr', 'https://www.migros.com.tr/arama?q={q}',
      cats: {'Market'}),
  _s('CarrefourSA', 'https://www.carrefoursa.com', 'https://www.carrefoursa.com/search/?text={q}',
      cats: {'Market'}),
  _s('Macrocenter', 'https://www.macrocenter.com.tr', 'https://www.macrocenter.com.tr/arama?q={q}',
      cats: {'Market'}),
  // BİM'in online satışı/araması yok: sadece haftalık aktüel ürünler sayfası açılır.
  _s('BİM Aktüel', 'https://www.bim.com.tr',
      'https://www.bim.com.tr/Categories/680/aktuel-urunler.aspx?x={q}',
      cats: {'Market'}, searchable: false),

  // ── Giyim & Spor
  _s('LC Waikiki', 'https://www.lcw.com', 'https://www.lcw.com/arama?q={q}', cats: {'Giyim'}),
  _s('DeFacto', 'https://www.defacto.com.tr', 'https://www.defacto.com.tr/arama?q={q}',
      cats: {'Giyim'}),
  _s('Koton', 'https://www.koton.com', 'https://www.koton.com/tr/search/?text={q}',
      cats: {'Giyim'}),
  _s('Boyner', 'https://www.boyner.com.tr', 'https://www.boyner.com.tr/arama?q={q}',
      cats: {'Giyim'}),
  _s('FLO', 'https://www.flo.com.tr', 'https://www.flo.com.tr/arama?q={q}',
      cats: {'Giyim', 'Spor'}),
  _s('Decathlon', 'https://www.decathlon.com.tr', 'https://www.decathlon.com.tr/search?Ntt={q}',
      cats: {'Spor'}),
  _s('Sportive', 'https://www.sportive.com.tr', 'https://www.sportive.com.tr/arama?q={q}',
      cats: {'Spor', 'Giyim'}),

  // ── Kozmetik & kişisel bakım
  _s('Gratis', 'https://www.gratis.com', 'https://www.gratis.com/arama?q={q}',
      cats: {'Kozmetik', 'Anne & Bebek'}),
  _s('Watsons', 'https://www.watsons.com.tr', 'https://www.watsons.com.tr/search?text={q}',
      cats: {'Kozmetik', 'Anne & Bebek'}),
  _s('Rossmann', 'https://www.rossmann.com.tr', 'https://www.rossmann.com.tr/arama?q={q}',
      cats: {'Kozmetik', 'Anne & Bebek', 'Market'}),
  _s('Sephora', 'https://www.sephora.com.tr', 'https://www.sephora.com.tr/search?q={q}',
      cats: {'Kozmetik'}),

  // ── Oyuncak
  _s('Toyzz Shop', 'https://www.toyzzshop.com', 'https://www.toyzzshop.com/arama?q={q}',
      cats: {'Oyuncak', 'Anne & Bebek'}),

  // ── Kitap
  _s('İdefix', 'https://www.idefix.com', 'https://www.idefix.com/search?q={q}', cats: {'Kitap'}),
  _s('Kitapyurdu', 'https://www.kitapyurdu.com',
      'https://www.kitapyurdu.com/index.php?route=product/search&filter_name={q}',
      cats: {'Kitap'}),
  _s('D&R', 'https://www.dr.com.tr', 'https://www.dr.com.tr/search?q={q}', cats: {'Kitap'}),
  _s('BKM Kitap', 'https://www.bkmkitap.com', 'https://www.bkmkitap.com/arama?q={q}',
      cats: {'Kitap'}),

  // ── Ev, yapı market, hediye
  _s('IKEA', 'https://www.ikea.com.tr', 'https://www.ikea.com.tr/arama?k={q}',
      cats: {'Ev & Yaşam'}),
  _s('Koçtaş', 'https://www.koctas.com.tr', 'https://www.koctas.com.tr/search?q={q}',
      cats: {'Ev & Yaşam', 'Yapı & Bahçe'}),
  _s('Tekzen', 'https://www.tekzen.com.tr', 'https://www.tekzen.com.tr/arama?q={q}',
      cats: {'Ev & Yaşam', 'Yapı & Bahçe'}),
  _s('English Home', 'https://www.englishhome.com', 'https://www.englishhome.com/arama?q={q}',
      cats: {'Ev & Yaşam'}),
  _s('Çiçeksepeti', 'https://www.ciceksepeti.com',
      'https://www.ciceksepeti.com/arama?query={q}', cats: {'Ev & Yaşam'}),

  // ── Evcil hayvan
  _s('Petlebi', 'https://www.petlebi.com', 'https://www.petlebi.com/arama?q={q}',
      cats: {'Evcil Hayvan'}),
];

/// "Tümü": sadece büyük genel siteler (hızlı). Diğer kategoriler: o kategorinin tüm siteleri.
List<Site> activeSites(String cat) => cat == 'Tümü'
    ? sites.where((s) => s.core).toList()
    : sites.where((s) => s.cats == null || s.cats!.contains(cat)).toList();

// Yavaş WebView yedeği her aramada en fazla bu kadar siteyle sınırlı (aramayı hızlı tutar).
int _webBudget = 4;
void resetWebBudget([int n = 4]) => _webBudget = n;

final _priceRe = RegExp(r'(\d{1,3}(?:\.\d{3})+|\d+)(?:,(\d{1,2}))?\s*(?:TL|₺)');

double _toDouble(RegExpMatch m) {
  final whole = m.group(1)!.replaceAll('.', '');
  final frac = m.group(2) ?? '0';
  return double.parse('$whole.$frac');
}

const _headers = {
  'User-Agent': mobileUA,
  'Accept-Language': 'tr-TR,tr;q=0.9',
  'Accept': 'text/html,application/xhtml+xml',
};

/// Siteye bağımlı olmayan genel ayrıştırıcı: link + yakınındaki "xxx TL" metnini eşleştirir.
List<Offer> parseOffers(Site s, String body) {
  final doc = parser.parse(body);
  final out = <Offer>[];
  final seen = <String>{};
  for (final a in doc.querySelectorAll('a[href]')) {
    Element? box = a;
    RegExpMatch? m;
    for (var i = 0; i < 4 && box != null; i++) {
      final t = box.text;
      if (t.length < 350) {
        m = _priceRe.firstMatch(t);
        if (m != null) break;
      }
      box = box.parent;
    }
    if (m == null) continue;
    var title = (a.attributes['title'] ?? a.text).replaceAll(RegExp(r'\s+'), ' ').trim();
    if (title.length < 5 || _priceRe.hasMatch(title) && title.length < 14) continue;
    if (title.length > 120) title = title.substring(0, 120);
    final href = a.attributes['href']!;
    if (href.startsWith('#') || href.startsWith('javascript')) continue;
    final url = Uri.parse(s.base).resolve(href).toString();
    if (!seen.add(url)) continue;
    out.add(Offer(s.name, title, m.group(0)!, _toDouble(m), url));
  }
  out.sort((a, b) => a.price.compareTo(b.price));
  return out.take(10).toList();
}

/// Önce hızlı HTTP; sonuç yoksa (JS ile çizilen site / bot engeli) WebView ile dener.
Future<List<Offer>> searchSite(Site s, String q, WebFetcher web) async {
  try {
    final r = await http
        .get(Uri.parse(s.searchUrl(q)), headers: _headers)
        .timeout(const Duration(seconds: 12));
    if (r.statusCode == 200) {
      final o = parseOffers(s, r.body);
      if (o.isNotEmpty) return o;
    }
  } catch (_) {}
  if (_webBudget <= 0) return [];
  _webBudget--;
  final html = await web.fetch(s.searchUrl(q));
  return parseOffers(s, html);
}

double? _num(String s) {
  s = s.trim();
  if (s.contains(',')) {
    s = s.replaceAll('.', '').replaceAll(',', '.');
  }
  return double.tryParse(s);
}

/// Ürün sayfasından fiyatı okur: meta etiket -> JSON-LD/JSON "price" -> sayfadaki ilk "TL".
double? priceFromHtml(String body) {
  final meta = RegExp(
          r'''(?:product:price:amount|itemprop=["']price["'])[^>]*?(?:content|value)=["']([\d.,]+)["']''',
          caseSensitive: false)
      .firstMatch(body);
  if (meta != null) {
    final v = _num(meta.group(1)!);
    if (v != null && v > 0) return v;
  }
  final js = RegExp(r'"(?:price|lowPrice|sellingPrice)"\s*:\s*"?([\d.,]+)"?').firstMatch(body);
  if (js != null) {
    final v = _num(js.group(1)!);
    if (v != null && v > 0) return v;
  }
  final text = parser.parse(body).body?.text ?? '';
  final m = _priceRe.firstMatch(text);
  return m == null ? null : _toDouble(m);
}

Future<double?> fetchPrice(String url, {WebFetcher? web}) async {
  try {
    final r = await http
        .get(Uri.parse(url), headers: _headers)
        .timeout(const Duration(seconds: 12));
    if (r.statusCode == 200) {
      final p = priceFromHtml(r.body);
      if (p != null) return p;
    }
  } catch (_) {}
  if (web == null) return null;
  return priceFromHtml(await web.fetch(url));
}
