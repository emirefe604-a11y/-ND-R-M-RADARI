import 'package:flutter/material.dart';

const orange = Color(0xFFFF6B00);
const heroGradient = LinearGradient(
  colors: [Color(0xFFFF8F2B), Color(0xFFFF5A00)],
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
);

bool isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;
Color bgColor(BuildContext c) => isDark(c) ? const Color(0xFF121212) : const Color(0xFFF6F4F1);
Color surface(BuildContext c) => isDark(c) ? const Color(0xFF1F1F1F) : Colors.white;
Color subtle(BuildContext c) => isDark(c) ? Colors.white60 : Colors.black54;
Color faint(BuildContext c) => isDark(c) ? Colors.white38 : Colors.black38;

const green = Color(0xFF1B8A3A);
const greenBg = Color(0xFFE3F6E8);

Widget logo(double size) => ClipRRect(
      borderRadius: BorderRadius.circular(size * 0.3),
      child: Image.asset('assets/icon.png', width: size, height: size),
    );

Widget pill(String text, {Color bg = const Color(0xFFFFEDE0), Color fg = orange}) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Text(text, style: TextStyle(color: fg, fontSize: 11, fontWeight: FontWeight.w700)),
    );

BoxDecoration cardBox(BuildContext c, {bool highlight = false}) => BoxDecoration(
      color: surface(c),
      borderRadius: BorderRadius.circular(22),
      border: highlight ? Border.all(color: orange.withOpacity(0.55), width: 1.4) : null,
      boxShadow: isDark(c)
          ? []
          : const [BoxShadow(color: Color(0x14000000), blurRadius: 18, offset: Offset(0, 6))],
    );

Color storeColor(String name) {
  final h = name.codeUnits.fold<int>(7, (a, b) => (a * 31 + b) & 0xFFFFFF);
  return HSLColor.fromAHSL(1, (h % 360).toDouble(), 0.62, 0.48).toColor();
}

Widget storeAvatar(String name, {double size = 44}) {
  final col = storeColor(name);
  return Container(
    width: size,
    height: size,
    alignment: Alignment.center,
    decoration: BoxDecoration(
        color: col.withOpacity(0.15), borderRadius: BorderRadius.circular(size * 0.32)),
    child: Text(
      name.isEmpty ? '?' : String.fromCharCode(name.runes.first).toUpperCase(),
      style: TextStyle(color: col, fontWeight: FontWeight.w800, fontSize: size * 0.45),
    ),
  );
}

/// Turuncu degrade başlık alanı
Widget hero(BuildContext c,
        {required String title, required String sub, Widget? bottom, VoidCallback? onSettings}) =>
    Container(
      padding: EdgeInsets.fromLTRB(20, MediaQuery.of(c).padding.top + 14, 20, 22),
      decoration: const BoxDecoration(
        gradient: heroGradient,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(34)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white.withOpacity(0.6), width: 2),
            ),
            child: logo(42),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
              Text(sub, style: const TextStyle(color: Colors.white70, fontSize: 12.5)),
            ]),
          ),
          if (onSettings != null)
            IconButton(
              onPressed: onSettings,
              icon: const Icon(Icons.tune_rounded, color: Colors.white),
            ),
        ]),
        if (bottom != null) ...[const SizedBox(height: 18), bottom],
      ]),
    );
