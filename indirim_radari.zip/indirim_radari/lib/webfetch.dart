import 'dart:async';
import 'dart:convert';
import 'package:webview_flutter/webview_flutter.dart';

const mobileUA =
    'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36';

/// JavaScript ile çizilen siteler için gizli WebView: sayfayı yükler, çizilmiş HTML'i verir.
class WebFetcher {
  final controller = WebViewController();
  Completer<void>? _loaded;
  Future<void> _queue = Future.value();

  WebFetcher() {
    controller
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(mobileUA)
      ..setNavigationDelegate(NavigationDelegate(onPageFinished: (_) {
        if (_loaded != null && !_loaded!.isCompleted) _loaded!.complete();
      }));
  }

  /// İstekler sırayla işlenir (tek WebView var).
  Future<String> fetch(String url) {
    final run = _queue.then((_) => _fetch(url));
    _queue = run.then((_) {}, onError: (_) {});
    return run;
  }

  Future<String> _fetch(String url) async {
    _loaded = Completer<void>();
    await controller.loadRequest(Uri.parse(url));
    try {
      await _loaded!.future.timeout(const Duration(seconds: 15));
    } on TimeoutException {
      // yarım yüklenmiş sayfadan da okumayı dene
    }
    // SPA'nın fiyatları çizmesini bekle: sayfada yeterince fiyat görününce hemen devam et
    for (var i = 0; i < 8; i++) {
      await Future.delayed(const Duration(milliseconds: 500));
      try {
        final n = await controller.runJavaScriptReturningResult(
            r"(document.body.innerText.match(/(₺|TL)/g)||[]).length");
        if ((int.tryParse(n.toString()) ?? 0) >= 6) break;
      } catch (_) {}
    }
    final r = await controller
        .runJavaScriptReturningResult('document.documentElement.outerHTML');
    var s = r.toString();
    if (s.startsWith('"')) {
      try {
        s = jsonDecode(s) as String;
      } catch (_) {}
    }
    return s;
  }
}
