import 'package:flutter/material.dart';
import 'notify.dart';
import 'store.dart';
import 'theme.dart';
import 'tracker.dart';

Future<void> showSettingsSheet(BuildContext context) async {
  var minutes = await Settings.intervalMin();
  if (!context.mounted) return;
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Ayarlar', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          const Text('Arka planda kontrol sıklığı', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: SegmentedButton<int>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: 15, label: Text('15 dk')),
                ButtonSegment(value: 30, label: Text('30 dk')),
                ButtonSegment(value: 60, label: Text('1 saat')),
              ],
              selected: {minutes},
              onSelectionChanged: (s) async {
                set(() => minutes = s.first);
                await Settings.setIntervalMin(s.first);
                await rescheduleChecks();
              },
            ),
          ),
          const SizedBox(height: 6),
          Text('Android arka planda en sık 15 dakikada bir kontrole izin verir.',
              style: TextStyle(color: subtle(ctx), fontSize: 12)),
          const SizedBox(height: 10),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const CircleAvatar(
                backgroundColor: Color(0xFFFFEDE0), child: Icon(Icons.battery_charging_full_rounded, color: orange)),
            title: const Text('Pil kısıtlamasını kaldır'),
            subtitle: const Text('Bildirimler gecikmeden gelsin'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: requestBatteryExemption,
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const CircleAvatar(
                backgroundColor: Color(0xFFFFEDE0), child: Icon(Icons.notifications_active_rounded, color: orange)),
            title: const Text('Test bildirimi gönder'),
            subtitle: const Text('Bildirimlerin çalıştığını kontrol et'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => Notify.show(
                1, '🔔 Test bildirimi', 'Bildirimler çalışıyor! Fiyat düşünce böyle haber vereceğim.'),
          ),
        ]),
      ),
    ),
  );
}
