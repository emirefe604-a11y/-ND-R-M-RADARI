import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class Notify {
  static final _p = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static Future<void> init() async {
    if (_ready) return;
    await _p.initialize(const InitializationSettings(
        android: AndroidInitializationSettings('ic_stat')));
    _ready = true;
  }

  static Future<void> requestPermission() async {
    await init();
    await _p
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  static Future<void> show(int id, String title, String body) async {
    await init();
    await _p.show(
      id,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          'indirimler',
          'İndirim bildirimleri',
          channelDescription: 'Takip ettiğiniz ürünler indirime girince bildirir',
          importance: Importance.high,
          priority: Priority.high,
          color: const Color(0xFFFF6B00),
          styleInformation: BigTextStyleInformation(body),
        ),
      ),
    );
  }
}
