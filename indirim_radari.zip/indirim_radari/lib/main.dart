import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'notify.dart';
import 'scraper.dart';
import 'search_page.dart';
import 'settings_sheet.dart';
import 'store.dart';
import 'theme.dart';
import 'track_page.dart';
import 'tracker.dart';
import 'webfetch.dart';

Future<void> main() async {
  runZonedGuarded(_start, (e, st) => debugPrint('Yakalanmamış hata: $e'));
}

Future<void> _start() async {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterError.onError = (d) => debugPrint('Flutter hatası: ${d.exception}');
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const App());
  // Bildirim ve arka plan kurulumu ilk ekranı bekletmesin
  try {
    await Notify.init();
    await schedulePriceChecks();
  } catch (_) {}
}

class App extends StatelessWidget {
  const App({super.key});

  ThemeData _theme(Brightness b) {
    final dark = b == Brightness.dark;
    return ThemeData(
      useMaterial3: true,
      brightness: b,
      colorScheme: ColorScheme.fromSeed(seedColor: orange, brightness: b).copyWith(primary: orange),
      scaffoldBackgroundColor: dark ? const Color(0xFF121212) : const Color(0xFFF6F4F1),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'İndirim Radarı',
        debugShowCheckedModeBanner: false,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        themeMode: ThemeMode.system,
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> with WidgetsBindingObserver {
  final _web = WebFetcher();
  final _tracked = ValueNotifier<List<Tracked>>([]);
  Timer? _timer;
  bool _refreshing = false;
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    Notify.requestPermission().catchError((_) {});
    _load();
    // Uygulama açıkken 3 dakikada bir hızlı kontrol
    _timer = Timer.periodic(const Duration(minutes: 3), (_) => _refresh());
  }

  @override
  void dispose() {
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _load() async => _tracked.value = await Store.load();

  Future<void> _refresh() async {
    if (_refreshing) return;
    _refreshing = true;
    try {
      await checkAll(web: _web);
      await _load();
    } catch (_) {
    } finally {
      _refreshing = false;
    }
  }

  void _say(String m) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m)));

  Future<void> _toggle(Offer o) async {
    final l = List<Tracked>.of(_tracked.value);
    final i = l.indexWhere((t) => t.url == o.url);
    var added = false;
    if (i >= 0) {
      l.removeAt(i);
      _say('Takip bırakıldı');
    } else {
      l.add(Tracked(
          url: o.url, title: o.title, store: o.store, price: o.price, image: o.image, checked: DateTime.now()));
      _say('Takibe alındı, fiyat düşünce bildirim gelecek 🔔');
      added = true;
    }
    await Store.save(l);
    _tracked.value = l;
    if (added) _maybeAskBattery();
  }

  /// İlk takipte bir kez: bildirimler gecikmesin diye pil kısıtlaması izni iste.
  Future<void> _maybeAskBattery() async {
    if (await Settings.batteryAsked()) return;
    await Settings.setBatteryAsked();
    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Bildirimler gecikmesin'),
        content: const Text(
            'Android pil tasarrufu, arka plandaki fiyat kontrollerini geciktirebilir. '
            'İndirim bildirimlerinin hemen gelmesi için İndirim Radarı\'nı pil kısıtlamasından çıkarın.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Daha sonra')),
          FilledButton(
              style: FilledButton.styleFrom(backgroundColor: orange),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Ayarla')),
        ],
      ),
    );
    if (ok == true) await requestBatteryExemption();
  }

  Future<void> _setTarget(Tracked t, double? v) async {
    final l = List<Tracked>.of(_tracked.value);
    final i = l.indexWhere((e) => e.url == t.url);
    if (i < 0) return;
    l[i].target = v;
    await Store.save(l);
    _tracked.value = l;
    _say(v == null ? 'Hedef fiyat kaldırıldı' : 'Hedef ${fmt(v)} · ulaşınca haber vereceğiz 🎯');
  }

  Future<void> _remove(Tracked t) async {
    final l = _tracked.value.where((e) => e.url != t.url).toList();
    await Store.save(l);
    _tracked.value = l;
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: const Text('Takip bırakıldı'),
        action: SnackBarAction(
          label: 'Geri al',
          onPressed: () async {
            final back = [..._tracked.value, t];
            await Store.save(back);
            _tracked.value = back;
          },
        ),
      ));
  }

  void _settings() => showSettingsSheet(context);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: Stack(children: [
        IndexedStack(index: _tab, children: [
          SearchPage(web: _web, tracked: _tracked, onToggle: _toggle, onSettings: _settings),
          TrackPage(
              tracked: _tracked,
              onRefresh: _refresh,
              onRemove: _remove,
              onTarget: _setTarget,
              onSettings: _settings),
        ]),
        // Gizli WebView: JS ile çizilen siteler için
        Positioned(left: 0, top: 0, width: 1, height: 1, child: WebViewWidget(controller: _web.controller)),
        Positioned(
          left: 48,
          right: 48,
          bottom: MediaQuery.of(context).padding.bottom + 14,
          child: ValueListenableBuilder<List<Tracked>>(
            valueListenable: _tracked,
            builder: (_, list, __) => _NavBar(
              index: _tab,
              badge: list.length,
              onTap: (i) => setState(() => _tab = i),
            ),
          ),
        ),
      ]),
    );
  }
}

/// Yüzen, yuvarlak alt menü
class _NavBar extends StatelessWidget {
  final int index, badge;
  final ValueChanged<int> onTap;
  const _NavBar({required this.index, required this.badge, required this.onTap});

  Widget _item(BuildContext c, int i, IconData icon, String label, {int badge = 0}) {
    final sel = index == i;
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => onTap(i),
        child: Center(
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOutCubic,
            padding: EdgeInsets.symmetric(horizontal: sel ? 20 : 14, vertical: 11),
            decoration: BoxDecoration(
              gradient: sel ? heroGradient : null,
              borderRadius: BorderRadius.circular(26),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Badge(
                isLabelVisible: badge > 0 && !sel,
                label: Text('$badge'),
                backgroundColor: orange,
                child: Icon(icon, size: 22, color: sel ? Colors.white : faint(c)),
              ),
              if (sel) ...[
                const SizedBox(width: 8),
                Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              ],
            ]),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Container(
        height: 66,
        padding: const EdgeInsets.symmetric(horizontal: 6),
        decoration: BoxDecoration(
          color: surface(context),
          borderRadius: BorderRadius.circular(33),
          boxShadow: const [BoxShadow(color: Color(0x30000000), blurRadius: 24, offset: Offset(0, 10))],
        ),
        child: Row(children: [
          _item(context, 0, Icons.search_rounded, 'Ara'),
          _item(context, 1, Icons.notifications_active_rounded, 'Takip', badge: badge),
        ]),
      );
}
