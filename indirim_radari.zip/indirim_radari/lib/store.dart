import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class Tracked {
  final String url, title, store;
  double price, initial, lowest;
  DateTime? checked;
  Tracked({
    required this.url,
    required this.title,
    required this.store,
    required this.price,
    double? initial,
    double? lowest,
    this.checked,
  })  : initial = initial ?? price,
        lowest = lowest ?? price;

  Map<String, dynamic> toJson() => {
        'url': url, 'title': title, 'store': store, 'price': price,
        'initial': initial, 'lowest': lowest,
        'checked': checked?.millisecondsSinceEpoch,
      };

  factory Tracked.fromJson(Map<String, dynamic> j) => Tracked(
        url: j['url'], title: j['title'], store: j['store'],
        price: (j['price'] as num).toDouble(),
        initial: (j['initial'] as num?)?.toDouble(),
        lowest: (j['lowest'] as num?)?.toDouble(),
        checked: j['checked'] == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(j['checked'] as int),
      );
}

class Store {
  static const _k = 'tracked_v1';

  static Future<List<Tracked>> load() async {
    final p = await SharedPreferences.getInstance();
    await p.reload(); // arka plan işleminin yazdıklarını görmek için
    final raw = p.getString(_k);
    if (raw == null) return [];
    return (jsonDecode(raw) as List)
        .map((e) => Tracked.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  static Future<void> save(List<Tracked> l) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_k, jsonEncode(l.map((e) => e.toJson()).toList()));
  }
}

/// 1299.9 -> "1.299,90 ₺"
String fmt(double v) {
  final p = v.toStringAsFixed(2).split('.');
  final w = p[0].replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => '.');
  return '$w${p[1] == '00' ? '' : ',${p[1]}'} ₺';
}
