import 'dart:convert';
import 'package:html/dom.dart';
import 'package:html/parser.dart' as parser;
import 'package:http/http.dart' as http;
import 'webfetch.dart';

class Offer {
  final String store, title, priceText, url;
  final double price;
  final double? oldPrice; // üstü çizili eski fiyat (varsa)
  final String? image; // ürün resmi adresi
  Offer(this.store, this.title, this.priceText, this.price, this.url, {this.oldPrice, this.image});

  /// Gerçek indirim yüzdesi (eski fiyat biliniyorsa), yoksa 0.
  int get discount =>
      oldPrice != null && oldPrice! > price ? ((oldPrice! - price) / oldPrice! * 100).round() : 0;

  Map<String, dynamic> toJson() => {
        'store': store, 'title': title, 'priceText': priceText, 'price': price,
        'url': url, 'oldPrice': oldPrice, 'image': image,
      };

  factory Offer.fromJson(Map<String, dynamic> j) => Offer(
        j['store'], j['title'], j['priceText'], (j['price'] as num).toDouble(), j['url'],
        oldPrice: (j['oldPrice'] as num?)?.toDouble(), image: j['image'] as String?);
}

class Site {
  final String name, base;
  final String Function(String q) searchUrl;
  final Set<String>? cats; // null = tüm kategoriler
  final bool searchable; // false = sadece sayfa açılır (ör. BİM)
  final bool core; // "Tümü" aramasına dahil mi?
  const Site(this.name, this.base, this.searchUrl,
      {this.cats, this.searchable = true, this.core = false});
}

String _q(String q) => Uri.encodeQueryComponent(q);

/// Arama adresi şablonu: {q} yerine aranan metin gelir.
Site _s(String name, String base, String tmpl,
        {Set<String>? cats, bool core = false, bool searchable = true}) =>
    Site(name, base, (q) => tmpl.replaceFirst('{q}', _q(q)),
        cats: cats, core: core, searchable: searchable);

const categories = [
  'Tümü', 'Market', 'Elektronik', 'Giyim', 'Ev & Yaşam', 'Yapı & Bahçe',
  'Kozmetik', 'Anne & Bebek', 'Spor', 'Oyuncak', 'Kitap', 'Evcil Hayvan',
];

// Yeni site eklemek için tek satır yeterli.
final sites = <Site>[
  // ── Genel (her kategoride aranır; core = "Tümü"de de aranır)
  _s('Cimri', 'https://www.cimri.com', 'https://www.cimri.com/arama?q={q}', core: true),
  _s('Akakçe', 'https://www.akakce.com', 'https://www.akakce.com/arama/?q={q}', core: true),
  _s('Trendyol', 'https://www.trendyol.com', 'https://www.trendyol.com/sr?q={q}', core: true),
  _s('Hepsiburada', 'https://www.hepsiburada.com', 'https://www.hepsiburada.com/ara?q={q}', core: true),
  _s('n11', 'https://www.n11.com', 'https://www.n11.com/arama?q={q}', core: true),
  _s('Amazon TR', 'https://www.amazon.com.tr', 'https://www.amazon.com.tr/s?k={q}', core: true),
  _s('PTT AVM', 'https://www.pttavm.com', 'https://www.pttavm.com/arama?q={q}'),
  _s('Pazarama', 'https://www.pazarama.com', 'https://www.pazarama.com/arama?q={q}'),

  // ── Elektronik
  _s('Epey', 'https://www.epey.com', 'https://www.epey.com/ara/?q={q}', cats: {'Elektronik'}),
  _s('Teknosa', 'https://www.teknosa.com', 'https://www.teknosa.com/arama?s={q}', cats: {'Elektronik'}),
  _s('MediaMarkt', 'https://www.mediamarkt.com.tr',
      'https://www.mediamarkt.com.tr/tr/search.html?query={q}', cats: {'Elektronik'}),
  _s('Vatan Bilgisayar', 'https://www.vatanbilgisayar.com',
      'https://www.vatanbilgisayar.com/arama/{q}/', cats: {'Elektronik'}),
  _s('İnceHesap', 'https://www.incehesap.com', 'https://www.incehesap.com/arama/?q={q}',
      cats: {'Elektronik'}),

  // ── Market
  _s('A101', 'https://www.a101.com.tr', 'https://www.a101.com.tr/arama?k={q}', cats: {'Market'}),
  _s('ŞOK', 'https://www.sokmarket.com.tr', 'https://www.sokmarket.com.tr/arama?q={q}',
      cats: {'Market'}),
  _s('Migros', 'https://www.migros.com.tr', 'https://www.migros.com.tr/arama?q={q}',
      cats: {'Market'}),
  _s('CarrefourSA', 'https://www.carrefoursa.com', 'https://www.carrefoursa.com/search/?text={q}',
      cats: {'Market'}),
  _s('Macrocenter', 'https://www.macrocenter.com.tr', 'https://www.macrocenter.com.tr/arama?q={q}',
      cats: {'Market'}),
  // BİM'in online satışı/araması yok: sadece haftalık aktüel ürünler sayfası açılır.
  _s('BİM Aktüel', 'https://www.bim.com.tr',
      'https://www.bim.com.tr/Categories/680/aktuel-urunler.aspx?x={q}',
      cats: {'Market'}, searchable: false),

  // ── Giyim & Spor
  _s('LC Waikiki', 'https://www.lcw.com', 'https://www.lcw.com/arama?q={q}', cats: {'Giyim'}),
  _s('DeFacto', 'https://www.defacto.com.tr', 'https://www.defacto.com.tr/arama?q={q}',
      cats: {'Giyim'}),
  _s('Koton', 'https://www.koton.com', 'https://www.koton.com/tr/search/?text={q}',
      cats: {'Giyim'}),
  _s('Boyner', 'https://www.boyner.com.tr', 'https://www.boyner.com.tr/arama?q={q}',
      cats: {'Giyim'}),
  _s('FLO', 'https://www.flo.com.tr', 'https://www.flo.com.tr/arama?q={q}',
      cats: {'Giyim', 'Spor'}),
  _s('Decathlon', 'https://www.decathlon.com.tr', 'https://www.decathlon.com.tr/search?Ntt={q}',
      cats: {'Spor'}),
  _s('Sportive', 'https://www.sportive.com.tr', 'https://www.sportive.com.tr/arama?q={q}',
      cats: {'Spor', 'Giyim'}),

  // ── Kozmetik & kişisel bakım
  _s('Gratis', 'https://www.gratis.com', 'https://www.gratis.com/arama?q={q}',
      cats: {'Kozmetik', 'Anne & Bebek'}),
  _s('Watsons', 'https://www.watsons.com.tr', 'https://www.watsons.com.tr/search?text={q}',
      cats: {'Kozmetik', 'Anne & Bebek'}),
  _s('Rossmann', 'https://www.rossmann.com.tr', 'https://www.rossmann.com.tr/arama?q={q}',
      cats: {'Kozmetik', 'Anne & Bebek', 'Market'}),
  _s('Sephora', 'https://www.sephora.com.tr', 'https://www.sephora.com.tr/search?q={q}',
      cats: {'Kozmetik'}),

  // ── Oyuncak
  _s('Toyzz Shop', 'https://www.toyzzshop.com', 'https://www.toyzzshop.com/arama?q={q}',
      cats: {'Oyuncak', 'Anne & Bebek'}),

  // ── Kitap
  _s('İdefix', 'https://www.idefix.com', 'https://www.idefix.com/search?q={q}', cats: {'Kitap'}),
  _s('Kitapyurdu', 'https://www.kitapyurdu.com',
      'https://www.kitapyurdu.com/index.php?route=product/search&filter_name={q}',
      cats: {'Kitap'}),
  _s('D&R', 'https://www.dr.com.tr', 'https://www.dr.com.tr/search?q={q}', cats: {'Kitap'}),
  _s('BKM Kitap', 'https://www.bkmkitap.com', 'https://www.bkmkitap.com/arama?q={q}',
      cats: {'Kitap'}),

  // ── Ev, yapı market, hediye
  _s('IKEA', 'https://www.ikea.com.tr', 'https://www.ikea.com.tr/arama?k={q}',
      cats: {'Ev & Yaşam'}),
  _s('Koçtaş', 'https://www.koctas.com.tr', 'https://www.koctas.com.tr/search?q={q}',
      cats: {'Ev & Yaşam', 'Yapı & Bahçe'}),
  _s('Tekzen', 'https://www.tekzen.com.tr', 'https://www.tekzen.com.tr/arama?q={q}',
      cats: {'Ev & Yaşam', 'Yapı & Bahçe'}),
  _s('English Home', 'https://www.englishhome.com', 'https://www.englishhome.com/arama?q={q}',
      cats: {'Ev & Yaşam'}),
  _s('Çiçeksepeti', 'https://www.ciceksepeti.com',
      'https://www.ciceksepeti.com/arama?query={q}', cats: {'Ev & Yaşam'}),

  // ── Evcil hayvan
  _s('Petlebi', 'https://www.petlebi.com', 'https://www.petlebi.com/arama?q={q}',
      cats: {'Evcil Hayvan'}),
  // ── Yurt dışı kaynaklı, Türkiye'ye gönderen pazaryerleri
  _s('Temu', 'https://www.temu.com', 'https://www.temu.com/tr/search_result.html?search_key={q}'),
  _s('AliExpress', 'https://tr.aliexpress.com', 'https://tr.aliexpress.com/wholesale?SearchText={q}'),
  _s('Shein', 'https://tr.shein.com', 'https://tr.shein.com/pdsearch/{q}/', cats: {'Giyim', 'Ev & Yaşam'}),
  _s('Dolap (2. el)', 'https://dolap.com', 'https://dolap.com/ara?q={q}', cats: {'Giyim'}),
  _s('Sahibinden', 'https://www.sahibinden.com', 'https://www.sahibinden.com/arama?query_text={q}'),

  // ── Ek elektronik / beyaz eşya
  _s('Bimeks', 'https://www.bimeks.com.tr', 'https://www.bimeks.com.tr/arama?q={q}', cats: {'Elektronik'}),
  _s('Itopya', 'https://www.itopya.com', 'https://www.itopya.com/arama/?q={q}', cats: {'Elektronik'}),
  _s('Gürgençler', 'https://www.gurgencler.com.tr', 'https://www.gurgencler.com.tr/arama?q={q}',
      cats: {'Elektronik'}),
  _s('Samsung TR', 'https://www.samsung.com/tr', 'https://www.samsung.com/tr/search/?searchvalue={q}',
      cats: {'Elektronik'}),
  _s('Arçelik', 'https://www.arcelik.com.tr', 'https://www.arcelik.com.tr/arama?q={q}',
      cats: {'Elektronik', 'Ev & Yaşam'}),
  _s('Vestel', 'https://www.vestel.com.tr', 'https://www.vestel.com.tr/arama?q={q}',
      cats: {'Elektronik', 'Ev & Yaşam'}),

  // ── Ek giyim & spor
  _s('Zara', 'https://www.zara.com', 'https://www.zara.com/tr/tr/search?searchTerm={q}', cats: {'Giyim'}),
  _s('H&M', 'https://www2.hm.com', 'https://www2.hm.com/tr_tr/search-results.html?q={q}', cats: {'Giyim'}),
  _s('Mavi', 'https://www.mavi.com', 'https://www.mavi.com/arama?q={q}', cats: {'Giyim'}),
  _s('Mudo', 'https://www.mudo.com.tr', 'https://www.mudo.com.tr/arama?q={q}', cats: {'Giyim', 'Ev & Yaşam'}),
  _s('Penti', 'https://www.penti.com', 'https://www.penti.com/tr/arama?q={q}', cats: {'Giyim'}),
  _s('Adidas', 'https://www.adidas.com.tr', 'https://www.adidas.com.tr/search?q={q}', cats: {'Spor', 'Giyim'}),
  _s('Nike', 'https://www.nike.com', 'https://www.nike.com/tr/w?q={q}', cats: {'Spor', 'Giyim'}),
  _s('Intersport', 'https://www.intersport.com.tr', 'https://www.intersport.com.tr/arama?q={q}',
      cats: {'Spor', 'Giyim'}),

  // ── Ek ev & yaşam
  _s('Vivense', 'https://www.vivense.com', 'https://www.vivense.com/arama?q={q}', cats: {'Ev & Yaşam'}),
  _s('Evidea', 'https://www.evidea.com', 'https://www.evidea.com/arama?q={q}', cats: {'Ev & Yaşam'}),
  _s('Karaca', 'https://www.karaca.com', 'https://www.karaca.com/arama?q={q}', cats: {'Ev & Yaşam'}),
  _s('Madame Coco', 'https://www.madamecoco.com', 'https://www.madamecoco.com/arama?q={q}',
      cats: {'Ev & Yaşam'}),

  // ── Ek kozmetik, bebek, kitap, evcil hayvan
  _s('Flormar', 'https://www.flormar.com.tr', 'https://www.flormar.com.tr/arama?q={q}', cats: {'Kozmetik'}),
  _s('Yves Rocher', 'https://www.yvesrocher.com.tr', 'https://www.yvesrocher.com.tr/search?q={q}',
      cats: {'Kozmetik'}),
  _s('Eve Shop', 'https://www.eveshop.com.tr', 'https://www.eveshop.com.tr/arama?q={q}', cats: {'Kozmetik'}),
  _s('Joker Bebek', 'https://www.joker.com.tr', 'https://www.joker.com.tr/arama?q={q}',
      cats: {'Anne & Bebek'}),
  _s('Nadir Kitap', 'https://www.nadirkitap.com',
      'https://www.nadirkitap.com/kitap-ara.php?kitap_Adi={q}', cats: {'Kitap'}),
  _s('Petzzshop', 'https://www.petzzshop.com', 'https://www.petzzshop.com/arama?q={q}',
      cats: {'Evcil Hayvan'}),
];

/// "Tümü": sadece büyük genel siteler (hızlı). Diğer kategoriler: o kategorinin tüm siteleri.
/// Kullanıcının elle seçtiği mağazalar (null = kategoriye göre otomatik)
Set<String>? selectedSites;

List<Site> activeSites(String cat) => (selectedSites != null && selectedSites!.isNotEmpty)
    ? sites.where((s) => selectedSites!.contains(s.name)).toList()
    : cat == 'Tümü'
    ? sites.where((s) => s.core).toList()
    : sites.where((s) => s.cats == null || s.cats!.contains(cat)).toList();

// Yavaş WebView yedeği her aramada en fazla bu kadar siteyle sınırlı (aramayı hızlı tutar).
int _webBudget = 3;
void resetWebBudget([int n = 3]) => _webBudget = n;

final _priceRe = RegExp(r'(\d{1,3}(?:\.\d{3})+|\d+)(?:,(\d{1,2}))?\s*(?:TL|₺)');
final _priceRe2 = RegExp(r'₺\s*(\d{1,3}(?:\.\d{3})+|\d+)(?:,(\d{1,2}))?');

double _toDouble(RegExpMatch m) {
  final whole = m.group(1)!.replaceAll('.', '');
  final frac = m.group(2) ?? '0';
  return double.parse('$whole.$frac');
}

final _badBefore = RegExp(
    r'(?:\d\s*[xX×]\s*|taksit|aylık|kargo|üzeri|kupon|puan|faiz|ek\s*indirim|bonus|hediye|param)\s*:?\s*$',
    caseSensitive: false);
final _badAfter = RegExp(
    r'^\s*(?:/\s*(?:ay|kg|lt|l|adet|gr|g|ml|m|cl)\b|[xX×]\s*\d|aylık|ay\b|taksit|ve\s*üzeri|üzeri|kargo|puan|bonus|hediye)',
    caseSensitive: false);

bool _isOldEl(Element e, Element box) {
  Element? x = e;
  while (x != null) {
    final n = x.localName ?? '';
    final c = x.attributes['class'] ?? '';
    if (n == 'del' || n == 's' || n == 'strike') return true;
    if (RegExp(r'(?:^|[\s_-])(?:old|eski|original|strike|list-?price|market)|line-through|Old|Original|Strike|ListPrice').hasMatch(c)) return true;
    if (identical(x, box)) break;
    x = x.parent;
  }
  return false;
}

/// "price/fiyat" sınıflı (üstü çizili olmayan) ilk öğeden güncel fiyatı okur.
double? _priceByClass(Element box) {
  for (final e in box.querySelectorAll(
      '[itemprop="price"], [class*="price"], [class*="Price"], [class*="fiyat"], [class*="Fiyat"], [class*="sale"], [class*="basket"]')) {
    if (_isOldEl(e, box)) continue;
    final c = e.attributes['content'];
    if (c != null) {
      final v = double.tryParse(c.replaceAll(',', '.'));
      if (v != null && v >= 1) return v;
    }
    final pr = allPrices(e.text);
    if (pr.isNotEmpty) return pr.first;
  }
  return null;
}

/// Metindeki tüm fiyatlar (sırayla): "1.299,90 TL", "₺1.299" ...
List<double> allPrices(String t) {
  final ms = <RegExpMatch>[..._priceRe.allMatches(t), ..._priceRe2.allMatches(t)]
    ..sort((a, b) => a.start.compareTo(b.start));
  final out = <double>[];
  for (final m in ms) {
    // Taksit, kargo limiti, birim fiyat, puan gibi "ürün fiyatı olmayan" rakamları ele
    final before = t.substring(m.start < 18 ? 0 : m.start - 18, m.start);
    final after = t.substring(m.end, m.end + 18 > t.length ? t.length : m.end + 18);
    if (_badBefore.hasMatch(before) || _badAfter.hasMatch(after)) continue;
    final v = _toDouble(m);
    if (v >= 1 && (out.isEmpty || out.last != v)) out.add(v);
  }
  return out;
}

const _headers = {
  'User-Agent': mobileUA,
  'Accept-Language': 'tr-TR,tr;q=0.9',
  'Accept': 'text/html,application/xhtml+xml',
};

const _oldSel = 'del, s, strike, [class^="old"], [class*=" old"], [class*="-old"], [class*="_old"], '
    '[class*="Old"], [class*="eski"], [class*="original"], [class*="Original"], [class*="strike"], '
    '[class*="line-through"], [class*="list-price"], [class*="listPrice"]';

String _fmtTl(double v) {
  final p = v.toStringAsFixed(2).split('.');
  final w = p[0].replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => '.');
  return '$w${p[1] == '00' ? '' : ',${p[1]}'} TL';
}

/// Resim adresini mutlak ve https yapar; geçersizse null.
String? _absImg(Site s, String? raw) {
  if (raw == null) return null;
  var r = raw.trim().replaceAll(r'\/', '/').replaceAll('&amp;', '&');
  if (r.isEmpty || r.startsWith('data:')) return null;
  if (r.contains(' ')) r = r.split(' ').first; // srcset: "url 2x"
  try {
    var u = Uri.parse(s.base).resolve(r).toString();
    if (u.startsWith('http://')) u = 'https://${u.substring(7)}';
    return u;
  } catch (_) {
    return null;
  }
}

String? _imgOf(Site s, Element box) {
  for (final img in box.querySelectorAll('img, source')) {
    final at = img.attributes;
    for (final k in ['data-src', 'data-original', 'data-lazy-src', 'data-lazy', 'src', 'srcset', 'data-srcset']) {
      var v = at[k];
      if (v == null || v.isEmpty) continue;
      if (k.contains('srcset')) v = v.split(',').first.trim();
      final u = _absImg(s, v);
      if (u != null && !u.toLowerCase().endsWith('.svg')) return u;
    }
  }
  return null;
}

/// Siteye bağımlı olmayan genel ayrıştırıcı: link + yakınındaki "xxx TL" metnini eşleştirir.
List<Offer> parseOffers(Site s, String body) {
  final out = <Offer>[];
  final seen = <String>{};
  try {
    final doc = parser.parse(body);
    for (final a in doc.querySelectorAll('a[href]')) {
      try {
        Element? box = a;
        List<double> prices = [];
        for (var i = 0; i < 5 && box != null; i++) {
          final t = box.text;
          if (t.length < 450) {
            prices = allPrices(t);
            if (prices.isNotEmpty) {
              // Birden çok ürünü içeren kapsayıcıya çıktıysak yanlış fiyat alırız: atla
              final hrefs = box.querySelectorAll('a[href]').map((e) => e.attributes['href']!)
                  .where((h) => !h.startsWith('#') && !h.startsWith('javascript')).toSet();
              if (hrefs.length > 3) prices = [];
              break;
            }
          }
          box = box.parent;
        }
        if (prices.isEmpty || box == null) continue;

        // Eski (üstü çizili) fiyat
        double? old;
        for (final e in box.querySelectorAll(_oldSel)) {
          final pr = allPrices(e.text);
          if (pr.isNotEmpty) {
            old = pr.first;
            break;
          }
        }
        double price;
        if (old != null) {
          final rest = prices.where((x) => x != old).toList();
          if (rest.isEmpty) {
            old = null;
            price = prices.first;
          } else {
            price = rest.first;
            if (old <= price) old = null;
          }
        } else if (prices.length >= 2 && box.text.length < 220 &&
            prices[0] > prices[1] && prices[1] / prices[0] > 0.2 && prices[1] / prices[0] < 0.97) {
          old = prices[0];
          price = prices[1];
        } else {
          price = prices.first;
        }

        final cp = _priceByClass(box);
        if (cp != null && cp != price) {
          price = cp;
          if (old != null && old <= price) old = null;
        }

        var title = (a.attributes['title'] ?? a.text).replaceAll(RegExp(r'\s+'), ' ').trim();
        if (title.length < 5 || (allPrices(title).isNotEmpty && title.length < 14)) continue;
        if (title.length > 120) title = title.substring(0, 120);
        final href = a.attributes['href']!;
        if (href.startsWith('#') || href.startsWith('javascript')) continue;
        final url = Uri.parse(s.base).resolve(href).toString();
        if (!seen.add(url)) continue;
        out.add(Offer(s.name, title, _fmtTl(price), price, url, oldPrice: old, image: _imgOf(s, box)));
      } catch (_) {}
    }
  } catch (_) {}
  out.addAll(parseJsonOffers(s, body, seen));
  out.sort((a, b) => a.price.compareTo(b.price));
  return out.take(12).toList();
}

double? _jnum(dynamic v) {
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v.replaceAll(',', '.'));
  return null;
}

/// JS ile çizilen sitelerde ürünler sayfaya gömülü JSON/JSON-LD olarak da bulunur.
List<Offer> parseJsonOffers(Site s, String body, Set<String> seen) {
  final out = <Offer>[];
  Offer? add(String name, double price, String? url, double? old, [String? img]) {
    if (name.length < 5 || price < 1) return null;
    if (url == null || url.isEmpty) return null;
    final u = Uri.parse(s.base).resolve(url.replaceAll(r'\/', '/')).toString();
    if (!seen.add(u)) return null;
    return Offer(s.name, name.length > 120 ? name.substring(0, 120) : name, _fmtTl(price), price, u,
        oldPrice: old != null && old > price ? old : null, image: _absImg(s, img));
  }

  // 1) JSON-LD
  try {
    final doc = parser.parse(body);
    void walk(dynamic n) {
      if (n is List) {
        for (final e in n) {
          walk(e);
        }
      } else if (n is Map) {
        final name = n['name'];
        final offers = n['offers'];
        if (name is String && offers != null) {
          final of = offers is List && offers.isNotEmpty ? offers.first : offers;
          if (of is Map) {
            final pr = _jnum(of['price'] ?? of['lowPrice']);
            final im = n['image'];
            final img = im is List && im.isNotEmpty
                ? (im.first is Map ? im.first['url'] : im.first)?.toString()
                : im is Map
                    ? im['url']?.toString()
                    : im?.toString();
            final o = pr == null ? null : add(name, pr, (n['url'] ?? of['url'])?.toString(), null, img);
            if (o != null) out.add(o);
          }
        }
        for (final v in n.values) {
          if (v is Map || v is List) walk(v);
        }
      }
    }

    for (final sc in doc.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        walk(jsonDecode(sc.text));
      } catch (_) {}
    }
  } catch (_) {}

  // 2) Sayfaya gömülü genel JSON: "name":"..." yakınında fiyat + url
  if (out.length < 3) {
    try {
      final nameRe = RegExp(r'"(?:name|productName|title)"\s*:\s*"([^"\\]{5,140})"');
      final priceRe = RegExp(
          r'"(?:sellingPrice|salePrice|discountedPrice|currentPrice|price)"\s*:\s*(?:\{[^{}]{0,60}?"(?:value|amount|text)"\s*:\s*)?"?(\d+(?:[.,]\d+)?)');
      final oldRe = RegExp(
          r'"(?:originalPrice|marketPrice|listPrice|oldPrice|retailPrice|strikePrice|strikeThroughPrice)"\s*:\s*(?:\{[^{}]{0,60}?"(?:value|amount|text)"\s*:\s*)?"?(\d+(?:[.,]\d+)?)');
      final imgRe = RegExp(
          r'"(?:image|imageUrl|imageURL|img|thumbnail|thumbnailUrl|mainImage)"\s*:\s*(?:\[\s*)?(?:\{[^{}]{0,80}?"url"\s*:\s*)?"((?:https?:)?\\?/\\?/[^"]+|/[^"]{5,})"');
      final urlRe = RegExp(r'"(?:url|link|href|productUrl)"\s*:\s*"([^"]{8,300})"');
      final names = nameRe.allMatches(body).toList();
      for (var ni = 0; ni < names.length; ni++) {
        final m = names[ni];
        if (out.length >= 12) break;
        var end = (m.end + 900).clamp(0, body.length);
        if (ni + 1 < names.length && names[ni + 1].start < end) end = names[ni + 1].start;
        final win = body.substring(m.end, end);
        final pm = priceRe.firstMatch(win);
        final um = urlRe.firstMatch(win);
        if (pm == null || um == null) continue;
        final om = oldRe.firstMatch(win);
        final im = imgRe.firstMatch(win);
        final o = add(m.group(1)!, _jnum(pm.group(1))!, um.group(1), om == null ? null : _jnum(om.group(1)), im?.group(1));
        if (o != null) out.add(o);
      }
    } catch (_) {}
  }
  return out;
}

/// Hızlı HTTP; [web] verilirse sonuç yoksa (JS ile çizilen site / bot engeli) WebView ile dener.
Future<List<Offer>> searchSite(Site s, String q, WebFetcher? web) async {
  try {
    final r = await http
        .get(Uri.parse(s.searchUrl(q)), headers: _headers)
        .timeout(const Duration(seconds: 7));
    if (r.statusCode == 200) {
      final o = parseOffers(s, r.body);
      if (o.isNotEmpty) return o;
    }
  } catch (_) {}
  if (web == null || _webBudget <= 0) return [];
  _webBudget--;
  final html = await web.fetch(s.searchUrl(q));
  return parseOffers(s, html);
}

/// Sadece WebView ile arar (HTTP aşaması sonuç vermeyen siteler için).
Future<List<Offer>> searchSiteWeb(Site s, String q, WebFetcher web) async {
  if (_webBudget <= 0) return [];
  _webBudget--;
  return parseOffers(s, await web.fetch(s.searchUrl(q)));
}

double? _num(String s) {
  s = s.trim();
  if (s.contains(',')) {
    s = s.replaceAll('.', '').replaceAll(',', '.');
  }
  return double.tryParse(s);
}

/// Ürün sayfasından fiyatı okur: meta etiket -> JSON-LD/JSON "price" -> sayfadaki ilk "TL".
double? priceFromHtml(String body) {
  try {
    double? ld;
    void walk(dynamic n) {
      if (ld != null) return;
      if (n is List) {
        n.forEach(walk);
      } else if (n is Map) {
        final of = n['offers'];
        if (of != null) {
          final o = of is List && of.isNotEmpty ? of.first : of;
          if (o is Map) {
            final v = _jnum(o['price'] ?? o['lowPrice']);
            if (v != null && v > 0) {
              ld = v;
              return;
            }
          }
        }
        n.values.forEach(walk);
      }
    }

    for (final sc in parser.parse(body).querySelectorAll('script[type="application/ld+json"]')) {
      try {
        walk(jsonDecode(sc.text));
      } catch (_) {}
      if (ld != null) return ld;
    }
  } catch (_) {}
  final meta = RegExp(
          r'''(?:product:price:amount|itemprop=["']price["'])[^>]*?(?:content|value)=["']([\d.,]+)["']''',
          caseSensitive: false)
      .firstMatch(body);
  if (meta != null) {
    final v = _num(meta.group(1)!);
    if (v != null && v > 0) return v;
  }
  final js = RegExp(r'"(?:price|lowPrice|sellingPrice)"\s*:\s*"?([\d.,]+)"?').firstMatch(body);
  if (js != null) {
    final v = _num(js.group(1)!);
    if (v != null && v > 0) return v;
  }
  final text = parser.parse(body).body?.text ?? '';
  final m = _priceRe.firstMatch(text);
  return m == null ? null : _toDouble(m);
}

Future<double?> fetchPrice(String url, {WebFetcher? web}) async {
  try {
    final r = await http
        .get(Uri.parse(url), headers: _headers)
        .timeout(const Duration(seconds: 10));
    if (r.statusCode == 200) {
      final p = priceFromHtml(r.body);
      if (p != null) return p;
    }
  } catch (_) {}
  if (web == null) return null;
  return priceFromHtml(await web.fetch(url));
}

String _norm(String s) => s
    .replaceAll('İ', 'i').replaceAll('I', 'ı').toLowerCase()
    .replaceAll('ı', 'i').replaceAll('ş', 's').replaceAll('ğ', 'g')
    .replaceAll('ü', 'u').replaceAll('ö', 'o').replaceAll('ç', 'c');

/// Aranan ürünle ilgisiz sonuçları ve aşırı ucuz (aksesuar/yedek parça) uç değerleri eler.
List<Offer> cleanOffers(String q, List<Offer> all) {
  var out = all;
  final toks = _norm(q).split(RegExp(r'[^a-z0-9]+')).where((t) => t.length >= 2).toList();
  final numeric = RegExp(r'^\d{6,}$').hasMatch(q.trim());
  // Tek parça ürün kodu (ör. SM-S918B, A2894, 8690000123456): başlıkta geçmeyebilir, filtreleme
  final isCode = toks.length <= 2 && RegExp(r'\d').hasMatch(q) && !q.trim().contains(' ');
  if (toks.isNotEmpty && !numeric && !isCode) {
    final need = (toks.length / 2).ceil();
    out = out.where((o) {
      final t = _norm(o.title);
      return toks.where(t.contains).length >= need;
    }).toList();
  }
  if (out.length >= 6) {
    final ps = out.map((o) => o.price).toList()..sort();
    final med = ps[ps.length ~/ 2];
    out = out.where((o) => o.price >= med * 0.25).toList();
  }
  return out;
}
