import 'dart:math' as math;
import 'package:android_intent_plus/android_intent.dart';
import 'package:workmanager/workmanager.dart';
import 'notify.dart';
import 'scraper.dart';
import 'store.dart';
import 'webfetch.dart';

/// Takipteki tüm ürünlerin fiyatını kontrol eder, düşenler için bildirim gönderir.
/// [web] verilirse (uygulama açıkken) JS ile çizilen sayfalar için WebView yedeği kullanılır.
Future<int> checkAll({WebFetcher? web}) async {
  final list = await Store.load();
  final notifyOn = await Settings.notifyOn();
  var drops = 0;
  final done = <String, Tracked>{};
  for (final t in list) {
    double? np;
    try {
      np = await fetchPrice(t.url, web: web);
    } catch (_) {}
    t.checked = DateTime.now();
    done[t.url] = t;
    if (np == null) continue;
    final diff = t.price - np;
    var drop = diff >= math.max(1.0, t.price * 0.005);
    // Şüpheli büyük düşüş (ayrıştırma hatası olabilir): ikinci kez doğrula
    if (drop && diff / t.price > 0.4) {
      double? again;
      try {
        again = await fetchPrice(t.url, web: web);
      } catch (_) {}
      if (again == null || (again - np).abs() > 0.01) continue;
    }
    // Hedef fiyat varsa: hedefe/altına inince bildir. Yoksa: her düşüşte bildir.
    final notifyNow = t.target != null ? (drop && np <= t.target!) : drop;
    if (notifyNow) {
      drops++;
      if (notifyOn) {
        final pct = (diff / t.price * 100).round();
        final record = np < t.lowest - 0.01;
        final head = record
            ? '🔥 Rekor düşük fiyat! ${t.store}'
            : t.target != null
                ? '🎯 Hedef fiyata ulaştı! ${t.store}'
                : '🔻 İndirime girdi! ${t.store}';
        try {
          await Notify.show(t.url.hashCode & 0x7fffffff, head,
              '${t.title}\n${fmt(t.price)} → ${fmt(np)}  (%$pct indirim)',
              payload: t.url);
        } catch (_) {}
      }
    }
    t.record(np);
    t.price = np;
    if (np < t.lowest) t.lowest = np;
  }
  // Kontrol sürerken kullanıcı takibi bıraktıysa/eklediyse ezme: güncel listeyi yeniden okuyup birleştir
  final fresh = await Store.load();
  for (final f in fresh) {
    final u = done[f.url];
    if (u == null) continue;
    f.price = u.price;
    f.lowest = u.lowest;
    f.checked = u.checked;
    f.history = u.history;
  }
  await Store.save(fresh);
  return drops;
}

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, input) async {
    try {
      await checkAll();
    } catch (_) {}
    return true;
  });
}

const _uid = 'indirim-radari-kontrol';

Future<void> _register(int minutes) => Workmanager().registerPeriodicTask(
      _uid,
      'fiyatKontrol',
      frequency: Duration(minutes: minutes), // Android alt sınırı 15 dk
      constraints: Constraints(networkType: NetworkType.connected),
    );

Future<void> schedulePriceChecks() async {
  await Workmanager().initialize(callbackDispatcher);
  await _register(await Settings.intervalMin());
}

/// Ayarlardan aralık değişince eski işi iptal edip yenisini kurar.
Future<void> rescheduleChecks() async {
  await Workmanager().cancelByUniqueName(_uid);
  await _register(await Settings.intervalMin());
}

/// Android pil kısıtlamasından muaf tutma isteği (bildirimlerin gecikmemesi için).
Future<void> requestBatteryExemption() async {
  try {
    await const AndroidIntent(
      action: 'android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS',
      data: 'package:com.indirimradari.indirim_radari',
    ).launch();
  } catch (_) {}
}
