import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class Tracked {
  final String url, title, store;
  double price, initial, lowest;
  double? target; // hedef fiyat (opsiyonel)
  DateTime? checked;
  List<List<double>> history; // [[zamanMs, fiyat], ...]

  Tracked({
    required this.url,
    required this.title,
    required this.store,
    required this.price,
    double? initial,
    double? lowest,
    this.target,
    this.checked,
    List<List<double>>? history,
  })  : initial = initial ?? price,
        lowest = lowest ?? price,
        history = history ??
            [
              [DateTime.now().millisecondsSinceEpoch.toDouble(), price]
            ];

  /// Fiyat değiştiyse geçmişe ekler (en fazla 60 nokta).
  void record(double p) {
    if (history.isEmpty || (history.last[1] - p).abs() > 0.01) {
      history.add([DateTime.now().millisecondsSinceEpoch.toDouble(), p]);
      if (history.length > 60) history.removeAt(0);
    }
  }

  Map<String, dynamic> toJson() => {
        'url': url, 'title': title, 'store': store, 'price': price,
        'initial': initial, 'lowest': lowest, 'target': target,
        'checked': checked?.millisecondsSinceEpoch,
        'history': history,
      };

  factory Tracked.fromJson(Map<String, dynamic> j) => Tracked(
        url: j['url'], title: j['title'], store: j['store'],
        price: (j['price'] as num).toDouble(),
        initial: (j['initial'] as num?)?.toDouble(),
        lowest: (j['lowest'] as num?)?.toDouble(),
        target: (j['target'] as num?)?.toDouble(),
        checked: j['checked'] == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(j['checked'] as int),
        history: (j['history'] as List?)
            ?.map((e) => (e as List).map((x) => (x as num).toDouble()).toList())
            .toList(),
      );
}

class Store {
  static const _k = 'tracked_v1';

  static Future<List<Tracked>> load() async {
    final p = await SharedPreferences.getInstance();
    await p.reload(); // arka plan işleminin yazdıklarını görmek için
    final raw = p.getString(_k);
    if (raw == null) return [];
    return (jsonDecode(raw) as List)
        .map((e) => Tracked.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  static Future<void> save(List<Tracked> l) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_k, jsonEncode(l.map((e) => e.toJson()).toList()));
  }
}

/// Son aramalar
class Recent {
  static const _k = 'recent_v1';

  static Future<List<String>> load() async {
    final p = await SharedPreferences.getInstance();
    return p.getStringList(_k) ?? [];
  }

  static Future<List<String>> add(String q) async {
    final p = await SharedPreferences.getInstance();
    final l = (p.getStringList(_k) ?? [])..remove(q);
    l.insert(0, q);
    if (l.length > 8) l.removeRange(8, l.length);
    await p.setStringList(_k, l);
    return l;
  }
}

/// 1299.9 -> "1.299,90 ₺"
String fmt(double v) {
  final p = v.toStringAsFixed(2).split('.');
  final w = p[0].replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => '.');
  return '$w${p[1] == '00' ? '' : ',${p[1]}'} ₺';
}

/// Kullanıcı ayarları
class Settings {
  static Future<int> intervalMin() async =>
      (await SharedPreferences.getInstance()).getInt('interval_min') ?? 15;
  static Future<void> setIntervalMin(int m) async =>
      (await SharedPreferences.getInstance()).setInt('interval_min', m);
  static Future<bool> batteryAsked() async =>
      (await SharedPreferences.getInstance()).getBool('battery_asked') ?? false;
  static Future<void> setBatteryAsked() async =>
      (await SharedPreferences.getInstance()).setBool('battery_asked', true);
}
