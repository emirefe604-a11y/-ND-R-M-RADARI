import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'store.dart';
import 'theme.dart';

class TrackPage extends StatelessWidget {
  final ValueNotifier<List<Tracked>> tracked;
  final Future<void> Function() onRefresh;
  final Future<void> Function(Tracked) onRemove;
  final Future<void> Function(Tracked, double?) onTarget;
  final VoidCallback onSettings;
  const TrackPage({
    super.key,
    required this.tracked,
    required this.onRefresh,
    required this.onRemove,
    required this.onTarget,
    required this.onSettings,
  });

  String _time(DateTime? d) => d == null
      ? '-'
      : '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      color: orange,
      edgeOffset: 120,
      onRefresh: onRefresh,
      child: ValueListenableBuilder<List<Tracked>>(
        valueListenable: tracked,
        builder: (_, list, __) {
          final cheaper = list.where((t) => t.price < t.initial - 0.01).toList();
          final saving = cheaper.fold<double>(0, (a, t) => a + (t.initial - t.price));
          return ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: EdgeInsets.zero,
            children: [
              hero(
                context,
                title: 'Takip listem',
                sub: 'Aşağı çekerek şimdi kontrol et',
                onSettings: onSettings,
                bottom: Row(children: [
                  _stat('Takipte', '${list.length}'),
                  const SizedBox(width: 10),
                  _stat('İndirimde', '${cheaper.length}'),
                  const SizedBox(width: 10),
                  _stat('Tasarruf', fmt(saving)),
                ]),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
                child: Column(children: [
                  if (list.isEmpty) _empty(context),
                  for (final t in list) _card(context, t),
                ]),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _stat(String label, String value) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
          decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(16)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11.5)),
            const SizedBox(height: 2),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(value,
                  style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
            ),
          ]),
        ),
      );

  Widget _empty(BuildContext c) => Padding(
        padding: const EdgeInsets.only(top: 50),
        child: Column(children: [
          Container(
            width: 96,
            height: 96,
            decoration: const BoxDecoration(shape: BoxShape.circle, gradient: heroGradient),
            child: const Icon(Icons.radar_rounded, size: 52, color: Colors.white),
          ),
          const SizedBox(height: 18),
          const Text('Henüz takip ettiğin ürün yok',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          const SizedBox(height: 6),
          Text('Arama sonuçlarında 🔔 simgesine dokun,\nfiyat düşünce hemen haber verelim.',
              textAlign: TextAlign.center, style: TextStyle(color: subtle(c))),
        ]),
      );

  Future<void> _editTarget(BuildContext context, Tracked t) async {
    final c = TextEditingController(text: t.target?.toStringAsFixed(0) ?? '');
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('🎯 Hedef fiyat', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text('Şu an ${fmt(t.price)}. Bu fiyata ya da altına düşünce haber verelim.',
              style: TextStyle(color: subtle(ctx))),
          const SizedBox(height: 14),
          TextField(
            controller: c,
            autofocus: true,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              suffixText: '₺',
              filled: true,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 14),
          Row(children: [
            if (t.target != null)
              TextButton(
                onPressed: () {
                  onTarget(t, null);
                  Navigator.pop(ctx);
                },
                child: const Text('Temizle'),
              ),
            const Spacer(),
            FilledButton(
              style: FilledButton.styleFrom(
                  backgroundColor: orange, padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14)),
              onPressed: () {
                final v = double.tryParse(c.text.replaceAll(',', '.'));
                if (v != null && v > 0) onTarget(t, v);
                Navigator.pop(ctx);
              },
              child: const Text('Kaydet'),
            ),
          ]),
        ]),
      ),
    );
  }

  Widget _card(BuildContext context, Tracked t) {
    final down = t.price < t.initial - 0.01;
    final pct = ((t.initial - t.price) / t.initial * 100).round();
    return Dismissible(
      key: ValueKey(t.url),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 24),
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(color: Colors.red.shade400, borderRadius: BorderRadius.circular(22)),
        child: const Icon(Icons.delete_outline_rounded, color: Colors.white),
      ),
      onDismissed: (_) => onRemove(t),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: cardBox(context, highlight: down),
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () => launchUrl(Uri.parse(t.url), mode: LaunchMode.externalApplication),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                storeAvatar(t.store, size: 42),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(t.store,
                        style: TextStyle(color: subtle(context), fontSize: 12, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 2),
                    Text(t.title, maxLines: 2, overflow: TextOverflow.ellipsis),
                  ]),
                ),
                const SizedBox(width: 8),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(fmt(t.price),
                      style: const TextStyle(color: orange, fontWeight: FontWeight.w800, fontSize: 19)),
                  const SizedBox(height: 4),
                  down
                      ? pill('↓ %$pct', bg: greenBg, fg: green)
                      : pill('Değişmedi', bg: Colors.grey.withOpacity(0.18), fg: subtle(context)),
                ]),
              ]),
              if (t.history.length >= 2) ...[
                const SizedBox(height: 12),
                SizedBox(height: 42, width: double.infinity, child: CustomPaint(painter: _Spark(t.history))),
              ],
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                  child: Text(
                    'En düşük ${fmt(t.lowest)} · Başlangıç ${fmt(t.initial)} · ${_time(t.checked)}',
                    style: TextStyle(color: faint(context), fontSize: 11),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                ActionChip(
                  visualDensity: VisualDensity.compact,
                  avatar: const Icon(Icons.flag_rounded, size: 15, color: orange),
                  label: Text(t.target == null ? 'Hedef' : fmt(t.target!), style: const TextStyle(fontSize: 12)),
                  onPressed: () => _editTarget(context, t),
                ),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Fiyat geçmişi mini grafiği
class _Spark extends CustomPainter {
  final List<List<double>> h;
  _Spark(this.h);

  @override
  void paint(Canvas canvas, Size s) {
    final ys = h.map((e) => e[1]).toList();
    final mn = ys.reduce(math.min), mx = ys.reduce(math.max);
    final span = (mx - mn) == 0 ? 1.0 : (mx - mn);
    Offset pt(int i) =>
        Offset(s.width * i / (h.length - 1), s.height - 5 - (s.height - 10) * (ys[i] - mn) / span);
    final line = Path()..moveTo(pt(0).dx, pt(0).dy);
    for (var i = 1; i < h.length; i++) {
      line.lineTo(pt(i).dx, pt(i).dy);
    }
    final fill = Path.from(line)
      ..lineTo(s.width, s.height)
      ..lineTo(0, s.height)
      ..close();
    canvas.drawPath(
        fill,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [orange.withOpacity(0.25), orange.withOpacity(0.0)],
          ).createShader(Offset.zero & s));
    canvas.drawPath(
        line,
        Paint()
          ..color = orange
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.2
          ..strokeJoin = StrokeJoin.round);
    canvas.drawCircle(pt(h.length - 1), 4.5, Paint()..color = Colors.white);
    canvas.drawCircle(pt(h.length - 1), 3.2, Paint()..color = orange);
  }

  @override
  bool shouldRepaint(covariant _Spark old) => true;
}
