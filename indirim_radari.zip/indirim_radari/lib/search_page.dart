import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_mlkit_barcode_scanning/google_mlkit_barcode_scanning.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'scraper.dart';
import 'store.dart';
import 'theme.dart';
import 'webfetch.dart';

class SearchPage extends StatefulWidget {
  final WebFetcher web;
  final ValueNotifier<List<Tracked>> tracked;
  final Future<void> Function(Offer) onToggle;
  const SearchPage({super.key, required this.web, required this.tracked, required this.onToggle});
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final _picker = ImagePicker();
  final _ctrl = TextEditingController();
  File? _image;
  bool _busy = false;
  String _status = '';
  String _cat = 'Tümü';
  List<Offer> _offers = [];
  final List<String> _errors = [];

  Future<void> _pick(ImageSource src) async {
    final x = await _picker.pickImage(source: src, imageQuality: 85);
    if (x == null) return;
    final f = File(x.path);
    setState(() {
      _image = f;
      _busy = true;
      _status = 'Ürün tanınıyor...';
    });
    String? q;
    try {
      q = await _recognize(f);
    } catch (e) {
      _status = 'Tanıma hatası: $e';
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (q == null || q.isEmpty) {
      setState(() => _status = 'Ürün okunamadı. Adını elle yazabilirsiniz.');
      return;
    }
    _ctrl.text = q;
    _search();
  }

  Future<String?> _recognize(File f) async {
    final input = InputImage.fromFile(f);
    final bs = BarcodeScanner();
    final codes = await bs.processImage(input);
    await bs.close();
    for (final c in codes) {
      final v = c.rawValue;
      if (v != null && v.isNotEmpty) return v;
    }
    final tr = TextRecognizer();
    final text = await tr.processImage(input);
    await tr.close();
    final lines = text.blocks
        .expand((b) => b.lines)
        .where((l) => l.text.trim().length > 2)
        .toList()
      ..sort((a, b) => b.boundingBox.height.compareTo(a.boundingBox.height));
    return lines.take(3).map((l) => l.text.trim()).join(' ');
  }

  Future<void> _search() async {
    final q = _ctrl.text.trim();
    if (q.isEmpty) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _busy = true;
      _status = '"$q" için fiyatlar aranıyor...';
      _offers = [];
      _errors.clear();
    });
    final all = <Offer>[];
    await Future.wait(activeSites(_cat).where((s) => s.searchable).map((s) async {
      try {
        all.addAll(await searchSite(s, q, widget.web));
      } catch (e) {
        _errors.add('${s.name}: erişilemedi');
      }
    }));
    all.sort((a, b) => a.price.compareTo(b.price));
    if (!mounted) return;
    setState(() {
      _offers = all;
      _busy = false;
      _status = all.isEmpty ? 'Sonuç bulunamadı.' : '${all.length} sonuç · ucuzdan pahalıya';
    });
  }

  Future<void> _open(String url) =>
      launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          pageHeader('İndirim Radarı', 'Ürünü bul, takip et, fiyat düşünce haber alalım'),
          TextField(
            controller: _ctrl,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _search(),
            decoration: InputDecoration(
              hintText: 'Ürün adı veya barkod',
              filled: true,
              fillColor: Colors.white,
              prefixIcon: const Icon(Icons.search),
              suffixIcon: IconButton(
                  icon: const Icon(Icons.arrow_forward_rounded, color: orange), onPressed: _search),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: _busy ? null : () => _pick(ImageSource.camera),
                icon: const Icon(Icons.photo_camera_rounded),
                label: const Text('Fotoğrafla tanı'),
                style: FilledButton.styleFrom(
                    backgroundColor: orange,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filledTonal(
              onPressed: _busy ? null : () => _pick(ImageSource.gallery),
              icon: const Icon(Icons.photo_library_rounded),
            ),
          ]),
          if (_image != null)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.file(_image!, height: 120, fit: BoxFit.cover),
              ),
            ),
          const SizedBox(height: 10),
          SizedBox(
            height: 38,
            child: ListView(scrollDirection: Axis.horizontal, children: [
              for (final c in categories)
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ChoiceChip(
                    label: Text(c),
                    selected: _cat == c,
                    showCheckmark: false,
                    selectedColor: orange,
                    labelStyle: TextStyle(
                        color: _cat == c ? Colors.white : Colors.black87,
                        fontWeight: FontWeight.w600),
                    onSelected: (_) => setState(() => _cat = c),
                  ),
                ),
            ]),
          ),
          if (_busy)
            const Padding(
                padding: EdgeInsets.only(top: 12),
                child: LinearProgressIndicator(color: orange, minHeight: 3)),
          if (_status.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Text(_status, style: const TextStyle(color: Colors.black54)),
            ),
          ValueListenableBuilder<List<Tracked>>(
            valueListenable: widget.tracked,
            builder: (_, list, __) => Column(children: [
              for (var i = 0; i < _offers.length; i++)
                _tile(_offers[i], i == 0, list.any((t) => t.url == _offers[i].url)),
            ]),
          ),
          if (_errors.isNotEmpty)
            Text(_errors.join(' · '), style: const TextStyle(color: Colors.redAccent, fontSize: 12)),
          if (_ctrl.text.trim().isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              for (final s in activeSites(_cat))
                ActionChip(
                  avatar: const Icon(Icons.open_in_new, size: 15),
                  label: Text('${s.name}\'da aç'),
                  onPressed: () => _open(s.searchUrl(_ctrl.text.trim())),
                ),
            ]),
          ],
        ],
      ),
    );
  }

  Widget _tile(Offer o, bool best, bool tracked) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: cardBox(),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => _open(o.url),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 6, 12),
            child: Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    pill(o.store),
                    if (best) ...[
                      const SizedBox(width: 6),
                      pill('En ucuz', bg: const Color(0xFFE3F6E8), fg: const Color(0xFF1B8A3A)),
                    ],
                  ]),
                  const SizedBox(height: 6),
                  Text(o.title, maxLines: 2, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Text(fmt(o.price),
                      style: const TextStyle(
                          color: orange, fontWeight: FontWeight.w800, fontSize: 18)),
                ]),
              ),
              IconButton(
                tooltip: tracked ? 'Takibi bırak' : 'Takip et',
                onPressed: () => widget.onToggle(o),
                icon: Icon(tracked ? Icons.notifications_active : Icons.notifications_none_rounded,
                    color: tracked ? orange : Colors.black45),
              ),
            ]),
          ),
        ),
      );
}
