import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:url_launcher/url_launcher.dart';

class Notify {
  static final _p = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static Future<void> init() async {
    if (_ready) return;
    await _p.initialize(
      const InitializationSettings(android: AndroidInitializationSettings('ic_stat')),
      // Bildirime dokununca ürün sayfası açılır
      onDidReceiveNotificationResponse: (r) {
        final u = r.payload;
        if (u != null && u.isNotEmpty) {
          launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);
        }
      },
    );
    _ready = true;
  }

  static Future<void> requestPermission() async {
    await init();
    await _p
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  static Future<void> show(int id, String title, String body, {String? payload}) async {
    await init();
    await _p.show(
      id,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          'indirimler',
          'İndirim bildirimleri',
          channelDescription: 'Takip ettiğiniz ürünler indirime girince bildirir',
          importance: Importance.max,
          category: AndroidNotificationCategory.promo,
          ticker: title,
          priority: Priority.high,
          color: const Color(0xFFFF6B00),
          styleInformation: BigTextStyleInformation(body),
        ),
      ),
      payload: payload,
    );
  }
}
