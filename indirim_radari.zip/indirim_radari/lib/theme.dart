import 'package:flutter/material.dart';

const orange = Color(0xFFFF6B00);
const bgColor = Color(0xFFFAF7F4);

Widget logo(double size) => ClipRRect(
      borderRadius: BorderRadius.circular(size * 0.28),
      child: Image.asset('assets/icon.png', width: size, height: size),
    );

Widget pill(String text, {Color bg = const Color(0xFFFFEDE0), Color fg = orange}) =>
    Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Text(text, style: TextStyle(color: fg, fontSize: 11, fontWeight: FontWeight.w600)),
    );

BoxDecoration cardBox({Color color = Colors.white}) => BoxDecoration(
      color: color,
      borderRadius: BorderRadius.circular(20),
      boxShadow: const [BoxShadow(color: Color(0x0F000000), blurRadius: 12, offset: Offset(0, 4))],
    );

Widget pageHeader(String title, String sub) => Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 16),
      child: Row(children: [
        logo(46),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            Text(sub, style: const TextStyle(color: Colors.black54, fontSize: 13)),
          ]),
        ),
      ]),
    );
