import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'store.dart';
import 'theme.dart';

class TrackPage extends StatelessWidget {
  final ValueNotifier<List<Tracked>> tracked;
  final Future<void> Function() onRefresh;
  final Future<void> Function(Tracked) onRemove;
  const TrackPage({super.key, required this.tracked, required this.onRefresh, required this.onRemove});

  String _time(DateTime? d) => d == null
      ? '-'
      : '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: RefreshIndicator(
        color: orange,
        onRefresh: onRefresh,
        child: ValueListenableBuilder<List<Tracked>>(
          valueListenable: tracked,
          builder: (_, list, __) => ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            children: [
              pageHeader('Takip listem', '${list.length} ürün izleniyor · çekerek yenile'),
              if (list.isEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 80),
                  child: Column(children: const [
                    Icon(Icons.radar, size: 72, color: Color(0xFFFFC299)),
                    SizedBox(height: 12),
                    Text('Henüz takip ettiğin ürün yok',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    SizedBox(height: 4),
                    Text('Arama sonuçlarında 🔔 simgesine dokun,\nfiyat düşünce bildirim gelsin.',
                        textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
                  ]),
                ),
              for (final t in list) _card(context, t),
            ],
          ),
        ),
      ),
    );
  }

  Widget _card(BuildContext context, Tracked t) {
    final down = t.price < t.initial - 0.01;
    final pct = ((t.initial - t.price) / t.initial * 100).round();
    return Dismissible(
      key: ValueKey(t.url),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 24),
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(color: Colors.red.shade400, borderRadius: BorderRadius.circular(20)),
        child: const Icon(Icons.delete_outline, color: Colors.white),
      ),
      onDismissed: (_) => onRemove(t),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: cardBox(),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => launchUrl(Uri.parse(t.url), mode: LaunchMode.externalApplication),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                pill(t.store),
                const Spacer(),
                Text('Son kontrol ${_time(t.checked)}',
                    style: const TextStyle(color: Colors.black45, fontSize: 11)),
              ]),
              const SizedBox(height: 8),
              Text(t.title, maxLines: 2, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 8),
              Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(fmt(t.price),
                    style: const TextStyle(
                        color: orange, fontWeight: FontWeight.w800, fontSize: 20)),
                const SizedBox(width: 8),
                if (down)
                  pill('↓ %$pct indirim', bg: const Color(0xFFE3F6E8), fg: const Color(0xFF1B8A3A))
                else
                  pill('Değişmedi', bg: const Color(0xFFF0F0F0), fg: Colors.black54),
                const Spacer(),
                Text('Takip başı ${fmt(t.initial)}',
                    style: const TextStyle(color: Colors.black45, fontSize: 11)),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}
