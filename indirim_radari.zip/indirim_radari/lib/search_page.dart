import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_barcode_scanning/google_mlkit_barcode_scanning.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'scraper.dart';
import 'store.dart';
import 'theme.dart';
import 'webfetch.dart';

const _catIcons = <String, IconData>{
  'Tümü': Icons.apps_rounded,
  'Market': Icons.shopping_basket_rounded,
  'Elektronik': Icons.devices_rounded,
  'Giyim': Icons.checkroom_rounded,
  'Ev & Yaşam': Icons.chair_rounded,
  'Yapı & Bahçe': Icons.hardware_rounded,
  'Kozmetik': Icons.face_retouching_natural_rounded,
  'Anne & Bebek': Icons.child_care_rounded,
  'Spor': Icons.sports_soccer_rounded,
  'Oyuncak': Icons.toys_rounded,
  'Kitap': Icons.menu_book_rounded,
  'Evcil Hayvan': Icons.pets_rounded,
};

class SearchPage extends StatefulWidget {
  final WebFetcher web;
  final ValueNotifier<List<Tracked>> tracked;
  final Future<void> Function(Offer) onToggle;
  final VoidCallback onSettings;
  const SearchPage({
    super.key,
    required this.web,
    required this.tracked,
    required this.onToggle,
    required this.onSettings,
  });
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final _picker = ImagePicker();
  final _ctrl = TextEditingController();
  File? _image;
  bool _busy = false;
  String _status = '';
  String _cat = 'Tümü';
  List<Offer> _offers = [];
  final List<String> _errors = [];
  List<String> _recent = [];

  @override
  void initState() {
    super.initState();
    Recent.load().then((r) {
      if (mounted) setState(() => _recent = r);
    });
  }

  Future<void> _pick(ImageSource src) async {
    final x = await _picker.pickImage(source: src, imageQuality: 85);
    if (x == null) return;
    final f = File(x.path);
    setState(() {
      _image = f;
      _busy = true;
      _status = 'Ürün tanınıyor...';
    });
    String? q;
    try {
      q = await _recognize(f);
    } catch (e) {
      _status = 'Tanıma hatası: $e';
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (q == null || q.isEmpty) {
      setState(() => _status = 'Ürün okunamadı. Adını elle yazabilirsiniz.');
      return;
    }
    _ctrl.text = q;
    _search();
  }

  Future<String?> _recognize(File f) async {
    final input = InputImage.fromFile(f);
    final bs = BarcodeScanner();
    final codes = await bs.processImage(input);
    await bs.close();
    for (final c in codes) {
      final v = c.rawValue;
      if (v != null && v.isNotEmpty) return v;
    }
    final tr = TextRecognizer();
    final text = await tr.processImage(input);
    await tr.close();
    final lines = text.blocks
        .expand((b) => b.lines)
        .where((l) => l.text.trim().length > 2)
        .toList()
      ..sort((a, b) => b.boundingBox.height.compareTo(a.boundingBox.height));
    return lines.take(3).map((l) => l.text.trim()).join(' ');
  }

  Future<void> _search() async {
    final q = _ctrl.text.trim();
    if (q.isEmpty) return;
    FocusScope.of(context).unfocus();
    Recent.add(q).then((r) {
      if (mounted) setState(() => _recent = r);
    });
    setState(() {
      _busy = true;
      _status = '"$q" aranıyor...';
      _offers = [];
      _errors.clear();
    });
    final all = <Offer>[];
    final list = activeSites(_cat).where((x) => x.searchable).toList();
    resetWebBudget();
    var done = 0;
    await Future.wait(list.map((x) async {
      try {
        all.addAll(await searchSite(x, q, widget.web));
      } catch (e) {
        _errors.add('${x.name}: erişilemedi');
      }
      done++;
      if (mounted) setState(() => _status = '"$q" aranıyor · $done/${list.length} site tarandı');
    }));
    all.sort((a, b) => a.price.compareTo(b.price));
    if (!mounted) return;
    setState(() {
      _offers = all;
      _busy = false;
      _status = all.isEmpty ? 'Sonuç bulunamadı.' : '${all.length} sonuç · ucuzdan pahalıya';
    });
  }

  Future<void> _open(String url) =>
      launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        hero(
          context,
          title: 'İndirim Radarı',
          sub: 'Bul · takip et · fiyat düşünce haber al',
          onSettings: widget.onSettings,
          bottom: Column(children: [
            _searchField(),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: _glass(Icons.photo_camera_rounded, 'Kamerayla tara',
                  _busy ? null : () => _pick(ImageSource.camera))),
              const SizedBox(width: 10),
              Expanded(child: _glass(Icons.photo_library_rounded, 'Galeriden seç',
                  _busy ? null : () => _pick(ImageSource.gallery))),
            ]),
          ]),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: [for (final c in categories) _catChip(c)],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (_image != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Image.file(_image!, height: 110, width: double.infinity, fit: BoxFit.cover),
                ),
              ),
            if (_status.isNotEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Row(children: [
                  if (_busy)
                    const Padding(
                      padding: EdgeInsets.only(right: 10),
                      child: SizedBox(
                          width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: orange)),
                    ),
                  Expanded(child: Text(_status, style: TextStyle(color: subtle(context)))),
                ]),
              ),
            if (_busy && _offers.isEmpty) _skeleton(context),
            ValueListenableBuilder<List<Tracked>>(
              valueListenable: widget.tracked,
              builder: (_, list, __) => Column(children: [
                for (var i = 0; i < _offers.length; i++)
                  _tile(context, _offers[i], i, list.any((t) => t.url == _offers[i].url)),
              ]),
            ),
            if (_errors.isNotEmpty)
              Text(_errors.join(' · '),
                  style: const TextStyle(color: Colors.redAccent, fontSize: 12)),
            if (_offers.isEmpty && !_busy && _recent.isNotEmpty) ...[
              const SizedBox(height: 8),
              const Text('Son aramalar', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 4, children: [
                for (final r in _recent)
                  ActionChip(
                    avatar: const Icon(Icons.history_rounded, size: 16),
                    label: Text(r),
                    onPressed: () {
                      _ctrl.text = r;
                      _search();
                    },
                  ),
              ]),
            ],
            if (_ctrl.text.trim().isNotEmpty) ...[
              const SizedBox(height: 14),
              Text('Siteler', style: TextStyle(color: subtle(context), fontSize: 12)),
              const SizedBox(height: 6),
              Wrap(spacing: 8, runSpacing: 2, children: [
                for (final s in activeSites(_cat))
                  ActionChip(
                    avatar: const Icon(Icons.open_in_new_rounded, size: 14),
                    label: Text(s.name, style: const TextStyle(fontSize: 12)),
                    onPressed: () => _open(s.searchUrl(_ctrl.text.trim())),
                  ),
              ]),
            ],
          ]),
        ),
      ],
    );
  }

  Widget _searchField() => Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [BoxShadow(color: Color(0x26000000), blurRadius: 18, offset: Offset(0, 8))],
        ),
        child: TextField(
          controller: _ctrl,
          style: const TextStyle(color: Colors.black87),
          cursorColor: orange,
          textInputAction: TextInputAction.search,
          onSubmitted: (_) => _search(),
          decoration: InputDecoration(
            hintText: 'Ürün adı veya barkod',
            hintStyle: const TextStyle(color: Colors.black38),
            prefixIcon: const Icon(Icons.search_rounded, color: Colors.black45),
            suffixIcon: Padding(
              padding: const EdgeInsets.all(7),
              child: InkWell(
                onTap: _search,
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  width: 40,
                  decoration: BoxDecoration(gradient: heroGradient, borderRadius: BorderRadius.circular(14)),
                  child: const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 20),
                ),
              ),
            ),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 16),
          ),
        ),
      );

  Widget _glass(IconData i, String t, VoidCallback? onTap) => Material(
        color: Colors.white.withOpacity(onTap == null ? 0.12 : 0.22),
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 13),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(i, color: Colors.white, size: 20),
              const SizedBox(width: 8),
              Text(t, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
            ]),
          ),
        ),
      );

  Widget _catChip(String c) {
    final sel = _cat == c;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: GestureDetector(
        onTap: () => setState(() => _cat = c),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            gradient: sel ? heroGradient : null,
            color: sel ? null : surface(context),
            borderRadius: BorderRadius.circular(22),
            boxShadow: sel || isDark(context)
                ? []
                : const [BoxShadow(color: Color(0x10000000), blurRadius: 8, offset: Offset(0, 3))],
          ),
          child: Row(children: [
            Icon(_catIcons[c] ?? Icons.category_rounded, size: 18, color: sel ? Colors.white : subtle(context)),
            const SizedBox(width: 6),
            Text(c,
                style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    color: sel ? Colors.white : null)),
          ]),
        ),
      ),
    );
  }

  Widget _skeleton(BuildContext c) {
    Widget bar(double w, double h) => Container(
        width: w,
        height: h,
        decoration: BoxDecoration(color: Colors.grey.withOpacity(0.18), borderRadius: BorderRadius.circular(6)));
    return Column(children: [
      for (var i = 0; i < 3; i++)
        Container(
          margin: const EdgeInsets.only(bottom: 12),
          height: 92,
          padding: const EdgeInsets.all(14),
          decoration: cardBox(c),
          child: Row(children: [
            Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(color: Colors.grey.withOpacity(0.15), borderRadius: BorderRadius.circular(15))),
            const SizedBox(width: 12),
            Expanded(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                bar(80, 10), const SizedBox(height: 8), bar(double.infinity, 12), const SizedBox(height: 8), bar(70, 14),
              ]),
            ),
          ]),
        ),
    ]);
  }

  Widget _tile(BuildContext c, Offer o, int i, bool tracked) {
    final best = i == 0;
    final base = _offers.first.price;
    final diff = best ? 0 : ((o.price - base) / base * 100).round();
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: cardBox(c, highlight: best),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () => _open(o.url),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 14, 10, 14),
          child: Row(children: [
            storeAvatar(o.store, size: 46),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Text(o.store, style: TextStyle(color: subtle(c), fontSize: 12, fontWeight: FontWeight.w700)),
                  if (best) ...[const SizedBox(width: 6), pill('EN UCUZ', bg: greenBg, fg: green)],
                ]),
                const SizedBox(height: 3),
                Text(o.title, maxLines: 2, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 6),
                Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(fmt(o.price),
                      style: const TextStyle(color: orange, fontWeight: FontWeight.w800, fontSize: 20)),
                  if (diff > 0) ...[
                    const SizedBox(width: 8),
                    Text('+%$diff', style: TextStyle(color: faint(c), fontSize: 12)),
                  ],
                ]),
              ]),
            ),
            IconButton(
              tooltip: tracked ? 'Takibi bırak' : 'Takip et',
              onPressed: () {
                HapticFeedback.lightImpact();
                widget.onToggle(o);
              },
              icon: AnimatedSwitcher(
                duration: const Duration(milliseconds: 200),
                child: Container(
                  key: ValueKey(tracked),
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: tracked ? heroGradient : null,
                    color: tracked ? null : Colors.grey.withOpacity(0.15),
                  ),
                  child: Icon(
                    tracked ? Icons.notifications_active_rounded : Icons.notifications_none_rounded,
                    size: 20,
                    color: tracked ? Colors.white : subtle(c),
                  ),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
