import 'package:workmanager/workmanager.dart';
import 'notify.dart';
import 'scraper.dart';
import 'store.dart';
import 'webfetch.dart';

/// Takipteki tüm ürünlerin fiyatını kontrol eder, düşenler için bildirim gönderir.
/// [web] verilirse (uygulama açıkken) JS ile çizilen sayfalar için WebView yedeği kullanılır.
Future<int> checkAll({WebFetcher? web}) async {
  final list = await Store.load();
  var drops = 0;
  for (final t in list) {
    double? np;
    try {
      np = await fetchPrice(t.url, web: web);
    } catch (_) {}
    t.checked = DateTime.now();
    if (np == null) continue;
    if (np < t.price - 0.01) {
      drops++;
      final pct = ((t.price - np) / t.price * 100).round();
      await Notify.show(t.url.hashCode & 0x7fffffff, 'İndirim! ${t.store}',
          '${t.title}\n${fmt(t.price)} → ${fmt(np)}  (%$pct)');
    }
    t.price = np;
    if (np < t.lowest) t.lowest = np;
  }
  await Store.save(list);
  return drops;
}

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, input) async {
    try {
      await checkAll();
    } catch (_) {}
    return true;
  });
}

Future<void> schedulePriceChecks() async {
  await Workmanager().initialize(callbackDispatcher);
  await Workmanager().registerPeriodicTask(
    'indirim-radari-kontrol',
    'fiyatKontrol',
    frequency: const Duration(hours: 1),
    constraints: Constraints(networkType: NetworkType.connected),
  );
}
