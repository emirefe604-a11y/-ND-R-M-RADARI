"""flutter create sonrası Android ayarları: izinler, uygulama adı, bildirim ikonu, desugaring."""
import pathlib, re, shutil

app = pathlib.Path('android/app')

# Manifest: izinler + uygulama adı
m = app / 'src/main/AndroidManifest.xml'
t = m.read_text(encoding='utf-8')
perms = ('    <uses-permission android:name="android.permission.INTERNET"/>\n'
         '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n'
         '    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>\n')
t = t.replace('<application', perms + '    <application', 1)
t = re.sub(r'android:label="[^"]*"', 'android:label="İndirim Radarı"', t, count=1)
m.write_text(t, encoding='utf-8')

# Bildirim küçük ikonu
d = app / 'src/main/res/drawable'
d.mkdir(parents=True, exist_ok=True)
shutil.copy('assets/ic_stat.png', d / 'ic_stat.png')

# flutter_local_notifications için core library desugaring
for name in ('build.gradle.kts', 'build.gradle'):
    g = app / name
    if not g.exists():
        continue
    s = g.read_text(encoding='utf-8')
    if name.endswith('.kts'):
        s = s.replace('compileOptions {', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', 1)
        s += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
    else:
        s = s.replace('compileOptions {', 'compileOptions {\n        coreLibraryDesugaringEnabled true', 1)
        s += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
    g.write_text(s, encoding='utf-8')
    break
print('Android yamaları uygulandı')
