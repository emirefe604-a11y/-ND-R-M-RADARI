import 'package:html/dom.dart';
import 'package:html/parser.dart' as parser;
import 'package:http/http.dart' as http;
import 'webfetch.dart';

class Offer {
  final String store, title, priceText, url;
  final double price;
  Offer(this.store, this.title, this.priceText, this.price, this.url);
}

class Site {
  final String name, base;
  final String Function(String q) searchUrl;
  final Set<String>? cats; // null = tüm kategoriler
  final bool searchable; // false = sadece sayfa açılır (ör. BİM)
  const Site(this.name, this.base, this.searchUrl, {this.cats, this.searchable = true});
}

String _q(String q) => Uri.encodeQueryComponent(q);

const categories = [
  'Tümü', 'Market', 'Elektronik', 'Giyim', 'Ev & Yaşam',
  'Kozmetik', 'Anne & Bebek', 'Spor', 'Oyuncak', 'Kitap',
];

// Yeni site eklemek için tek satır yeterli.
final sites = <Site>[
  // Genel (her kategori)
  Site('Cimri', 'https://www.cimri.com', (q) => 'https://www.cimri.com/arama?q=${_q(q)}'),
  Site('Akakçe', 'https://www.akakce.com', (q) => 'https://www.akakce.com/arama/?q=${_q(q)}'),
  Site('Trendyol', 'https://www.trendyol.com', (q) => 'https://www.trendyol.com/sr?q=${_q(q)}'),
  Site('Hepsiburada', 'https://www.hepsiburada.com', (q) => 'https://www.hepsiburada.com/ara?q=${_q(q)}'),
  Site('n11', 'https://www.n11.com', (q) => 'https://www.n11.com/arama?q=${_q(q)}'),
  // Elektronik
  Site('Epey', 'https://www.epey.com', (q) => 'https://www.epey.com/ara/?q=${_q(q)}',
      cats: {'Elektronik'}),
  // Market
  Site('A101', 'https://www.a101.com.tr', (q) => 'https://www.a101.com.tr/arama?k=${_q(q)}',
      cats: {'Market'}),
  Site('ŞOK', 'https://www.sokmarket.com.tr', (q) => 'https://www.sokmarket.com.tr/arama?q=${_q(q)}',
      cats: {'Market'}),
  Site('Migros', 'https://www.migros.com.tr', (q) => 'https://www.migros.com.tr/arama?q=${_q(q)}',
      cats: {'Market'}),
  Site('CarrefourSA', 'https://www.carrefoursa.com',
      (q) => 'https://www.carrefoursa.com/search/?text=${_q(q)}',
      cats: {'Market'}),
  // BİM'in online satışı/araması yok: sadece haftalık aktüel ürünler sayfası açılır.
  Site('BİM Aktüel', 'https://www.bim.com.tr',
      (q) => 'https://www.bim.com.tr/Categories/680/aktuel-urunler.aspx',
      cats: {'Market'}, searchable: false),
];

List<Site> activeSites(String cat) => sites
    .where((s) => cat == 'Tümü' || s.cats == null || s.cats!.contains(cat))
    .toList();

final _priceRe = RegExp(r'(\d{1,3}(?:\.\d{3})+|\d+)(?:,(\d{1,2}))?\s*(?:TL|₺)');

double _toDouble(RegExpMatch m) {
  final whole = m.group(1)!.replaceAll('.', '');
  final frac = m.group(2) ?? '0';
  return double.parse('$whole.$frac');
}

const _headers = {
  'User-Agent': mobileUA,
  'Accept-Language': 'tr-TR,tr;q=0.9',
  'Accept': 'text/html,application/xhtml+xml',
};

/// Siteye bağımlı olmayan genel ayrıştırıcı: link + yakınındaki "xxx TL" metnini eşleştirir.
List<Offer> parseOffers(Site s, String body) {
  final doc = parser.parse(body);
  final out = <Offer>[];
  final seen = <String>{};
  for (final a in doc.querySelectorAll('a[href]')) {
    Element? box = a;
    RegExpMatch? m;
    for (var i = 0; i < 4 && box != null; i++) {
      final t = box.text;
      if (t.length < 350) {
        m = _priceRe.firstMatch(t);
        if (m != null) break;
      }
      box = box.parent;
    }
    if (m == null) continue;
    var title = (a.attributes['title'] ?? a.text).replaceAll(RegExp(r'\s+'), ' ').trim();
    if (title.length < 5 || _priceRe.hasMatch(title) && title.length < 14) continue;
    if (title.length > 120) title = title.substring(0, 120);
    final href = a.attributes['href']!;
    if (href.startsWith('#') || href.startsWith('javascript')) continue;
    final url = Uri.parse(s.base).resolve(href).toString();
    if (!seen.add(url)) continue;
    out.add(Offer(s.name, title, m.group(0)!, _toDouble(m), url));
  }
  out.sort((a, b) => a.price.compareTo(b.price));
  return out.take(10).toList();
}

/// Önce hızlı HTTP; sonuç yoksa (JS ile çizilen site / bot engeli) WebView ile dener.
Future<List<Offer>> searchSite(Site s, String q, WebFetcher web) async {
  try {
    final r = await http
        .get(Uri.parse(s.searchUrl(q)), headers: _headers)
        .timeout(const Duration(seconds: 12));
    if (r.statusCode == 200) {
      final o = parseOffers(s, r.body);
      if (o.isNotEmpty) return o;
    }
  } catch (_) {}
  final html = await web.fetch(s.searchUrl(q));
  return parseOffers(s, html);
}

double? _num(String s) {
  s = s.trim();
  if (s.contains(',')) {
    s = s.replaceAll('.', '').replaceAll(',', '.');
  }
  return double.tryParse(s);
}

/// Ürün sayfasından fiyatı okur: meta etiket -> JSON-LD/JSON "price" -> sayfadaki ilk "TL".
double? priceFromHtml(String body) {
  final meta = RegExp(
          r'''(?:product:price:amount|itemprop=["']price["'])[^>]*?(?:content|value)=["']([\d.,]+)["']''',
          caseSensitive: false)
      .firstMatch(body);
  if (meta != null) {
    final v = _num(meta.group(1)!);
    if (v != null && v > 0) return v;
  }
  final js = RegExp(r'"(?:price|lowPrice|sellingPrice)"\s*:\s*"?([\d.,]+)"?').firstMatch(body);
  if (js != null) {
    final v = _num(js.group(1)!);
    if (v != null && v > 0) return v;
  }
  final text = parser.parse(body).body?.text ?? '';
  final m = _priceRe.firstMatch(text);
  return m == null ? null : _toDouble(m);
}

Future<double?> fetchPrice(String url, {WebFetcher? web}) async {
  try {
    final r = await http
        .get(Uri.parse(url), headers: _headers)
        .timeout(const Duration(seconds: 12));
    if (r.statusCode == 200) {
      final p = priceFromHtml(r.body);
      if (p != null) return p;
    }
  } catch (_) {}
  if (web == null) return null;
  return priceFromHtml(await web.fetch(url));
}
